<div class="Sidebar">
                <div class="SidebarContents">
                    <div class="Account">
                        <div class="SidebarAccountName">
                            <span title="<?php
                                            $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                            if ($conn->connect_error) {
                                                die("Connection failed:" . $conn->connect_error);
                                            }
                                            $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Student'];
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo $row['Name'];
                                                }
                                            } else {
                                                echo "0 result";
                                            }
                                            $conn->close();
                                            ?>">
                                <?php
                                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                if ($conn->connect_error) {
                                    die("Connection failed:" . $conn->connect_error);
                                }
                                $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Student'];
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo $row['Name'];
                                    }
                                } else {
                                    echo "0 result";
                                }
                                $conn->close();
                                ?></span>
                        </div>
                        <div class="SidebarAccountEmail" id="SidebarAccountEmail"><span title="
                        <?php
                        $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                        if ($conn->connect_error) {
                            die("Connection failed:" . $conn->connect_error);
                        }
                        $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Student'];
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo $row['O365'];
                            }
                        } else {
                            echo "0 result";
                        }
                        $conn->close();
                        ?>"><?php
                            $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                            if ($conn->connect_error) {
                                die("Connection failed:" . $conn->connect_error);
                            }
                            $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Student'];
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo $row['O365'];
                                }
                            } else {
                                echo "0 result";
                            }
                            $conn->close();
                            ?></span></div>
                        <div class="SidebarAccountContactNo">
                            <span title="<?php
                                            $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                            if ($conn->connect_error) {
                                                die("Connection failed:" . $conn->connect_error);
                                            }
                                            $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Student'];
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo $row['ContactNo'];
                                                }
                                            } else {
                                                echo "0 result";
                                            }
                                            $conn->close();
                                            ?>"><?php
                                                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                                if ($conn->connect_error) {
                                                    die("Connection failed:" . $conn->connect_error);
                                                }
                                                $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Student'];
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo $row['ContactNo'];
                                                    }
                                                } else {
                                                    echo "0 result";
                                                }
                                                $conn->close();
                                                ?></span>
                        </div>
                        <div class="HROne"></div>
                    </div>
                    <div class="Buttons">
                        <table class="ButtonContainer">
                            <tr>
                                <td><button class="Button" onclick="location.replace('StudentBooks.php?Student=<?php echo $_GET['Student'];?>');">Books</button></td>
                            </tr>
                            <tr>
                                <td><button class="Button" onclick="location.replace('StudentReserve.php?Student=<?php echo $_GET['Student'];?>');">Check out form</button></td>
                            </tr>
                            <tr>
                                <td><button class="Button" onclick="location.replace('StudentReservations.php?Student=<?php echo $_GET['Student'];?>');">My reservation</button></td>
                            </tr>
                        </table>
                    </div>
                    <div class="Options">
                        <div class="HRTwo"></div>
                        <a href="AccountEdit.php?Student=<?php echo $_GET['Student'];?>" class="Option OptionOne">Edit Account</a>
                        <a href="logout.inc.php" class="Option OptionThree">Logout</a>
                    </div>
                </div>
            </div>