<div class="Sidebar">
                <div class="SidebarContents">
                    <div class="Account">
                        <div class="SidebarAccountName">
                            <span title="<?php
                                            $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                            if ($conn->connect_error) {
                                                die("Connection failed:" . $conn->connect_error);
                                            }
                                            $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Admin'];
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo $row['Name'];
                                                }
                                            } else {
                                                echo "0 result";
                                            }
                                            $conn->close();
                                            ?>">
                                <?php
                                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                if ($conn->connect_error) {
                                    die("Connection failed:" . $conn->connect_error);
                                }
                                $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Admin'];
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo $row['Name'];
                                    }
                                } else {
                                    echo "0 result";
                                }
                                $conn->close();
                                ?></span>
                        </div>
                        <div class="SidebarAccountEmail" id="SidebarAccountEmail"><span title="
                        <?php
                        $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                        if ($conn->connect_error) {
                            die("Connection failed:" . $conn->connect_error);
                        }
                        $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Admin'];
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo $row['O365'];
                            }
                        } else {
                            echo "0 result";
                        }
                        $conn->close();
                        ?>"><?php
                            $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                            if ($conn->connect_error) {
                                die("Connection failed:" . $conn->connect_error);
                            }
                            $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Admin'];
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo $row['O365'];
                                }
                            } else {
                                echo "0 result";
                            }
                            $conn->close();
                            ?></span></div>
                        <div class="SidebarAccountContactNo">
                            <span title="<?php
                                            $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                            if ($conn->connect_error) {
                                                die("Connection failed:" . $conn->connect_error);
                                            }
                                            $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Admin'];
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo $row['ContactNo'];
                                                }
                                            } else {
                                                echo "0 result";
                                            }
                                            $conn->close();
                                            ?>"><?php
                                                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                                if ($conn->connect_error) {
                                                    die("Connection failed:" . $conn->connect_error);
                                                }
                                                $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Admin'];
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo $row['ContactNo'];
                                                    }
                                                } else {
                                                    echo "0 result";
                                                }
                                                $conn->close();
                                                ?></span>
                        </div>
                        <div class="HROne"></div>
                    </div>
                    <div class="Buttons">
                        <table class="ButtonContainer">
                            <tr>
                                <td><button class="Button" onclick="location.replace('AdminBooks.php?Admin=<?php echo $_GET['Admin'];?>');">Books</button></td>
                            </tr>
                            <tr>
                                <td><button class="Button" onclick="location.replace('AdminReserve.php?Admin=<?php echo $_GET['Admin'];?>');">Check out form</button></td>
                            </tr>
                            <tr>
                                <td><button class="Button" onclick="location.replace('AdminReservations.php?Admin=<?php echo $_GET['Admin'];?>');">Reservations</button></td>
                            </tr>
                            <tr>
                                <td><button class="Button" onclick="location.replace('AdminEdit.php?Admin=<?php echo $_GET['Admin'];?>');">Edit</button></td>
                            </tr>
                            <tr>
                                <td><button class="Button" onclick="location.replace('AdminProfiles.php?Admin=<?php echo $_GET['Admin'];?>');">Profiles</button></td>
                            </tr>
                        </table>
                    </div>
                    <div class="Options">
                        <div class="HRTwo"></div>
                        <a href="AccountEdit.php?Admin=<?php echo $_GET['Admin'];?>" class="Option OptionOne">Edit Account</a>
                        <a href="logout.inc.php" class="Option OptionThree">Logout</a>
                    </div>
                </div>
            </div>