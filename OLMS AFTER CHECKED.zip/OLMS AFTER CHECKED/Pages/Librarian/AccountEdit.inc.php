<?php
if (isset($_POST['Continue'])) {
    $serverName = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'accountsystem';
    $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
    if (!$conn) {
        die("Connection Failed:" . mysqli_connect_error());
    }
    $Email = $_POST['Email'];
    $Name = $_POST['FullName'];
    $Password = $_POST['Password'];
    $ConfirmPassword = $_POST['ConfirmPassword'];
    $No = $_POST['ContactNumber'];
    if ($Password !== $ConfirmPassword) {
        echo "Password don't match";
    }
    else{
    $sqli = "UPDATE tblaccounts SET O365=?, Name=?, Password=?, ContactNo=? WHERE tblaccounts.Id =" . $_GET['Librarian'];
    $stmt = $conn->prepare($sqli);
    $HashedPassword = password_hash($Password, PASSWORD_DEFAULT);
    $stmt->bind_param('ssss', $Email, $Name, $HashedPassword, $No);
    $stmt->execute();
    header("location: LibrarianBooks.php?Librarian=" . $_GET['Librarian']);
    }
}

