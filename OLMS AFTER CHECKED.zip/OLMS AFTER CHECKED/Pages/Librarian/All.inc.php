<?php
if (isset($_POST['Checkout'])) {
  $UserId = $_POST['Librarian'];
  $BookkId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $sql = 'SELECT * FROM tblaccounts WHERE Id=' . $_POST['Librarian'];
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $dup = mysqli_query($conn, "SELECT * FROM tblreserveticket WHERE BookId = $BookkId AND AccountId = $UserId");
      if (mysqli_num_rows($dup) > 0) {
        header("location: LibrarianBooks.php?Librarian=$UserId");
      } else {
        $sqll = 'SELECT * FROM tblbooks WHERE BookId=' . $_POST['View'];
  $resultt = $conn->query($sqll);
  if ($resultt->num_rows > 0) {
    while ($roww = $resultt->fetch_assoc()) {
        $AccountId = $row["Id"];
        $AccountName = $row["Name"];
        $AccountO365 = $row["O365"];
        $AccountNo = $row["ContactNo"];
        $BookId = $roww["BookId"];
        $BookTitle = $roww["BookTitle"];
        $BookAuthor = $roww["BookAuthor"];
        $BookDescription = $roww["BookDescription"];
        $BookPublishingDate = $roww["PublishingDate"];
        $BookCompany = $roww["PublishingCompany"];
        $sqli = "INSERT INTO tblreserveticket (AccountId, AccountName, AccountO365, AccountNo, BookId, BookTitle, BookAuthor, BookDescription, BookPublishingCompany, BookPublishingDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssssssss", $AccountId, $AccountName, $AccountO365, $AccountNo, $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookCompany, $BookPublishingDate);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: LibrarianBooks.php?Librarian=" . $_POST['Librarian']);
        exit();
      }
    }
      }
    }
    $conn->close();
    mysqli_close($conn);
  } else {
    echo "0";
  }
  echo "1";
}
if (isset($_POST['Remove'])) {
  $Librarian = $_POST['Librarian'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
    mysqli_query($conn, 'DELETE FROM tblcart WHERE BookId=' . $id);
  }
  if ($chkarr) {
    echo ("<script>location.replace('LibrarianCart.php?Librarian=$Librarian');</script>");
  }
  mysqli_close($conn);
}
if (isset($_POST['Delete'])) {
  $Librarian = $_POST['Librarian'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  mysqli_query($conn, 'DELETE FROM tblreserveticket WHERE BookId=' . $BookId);
  echo ("<script>location.replace('LibrarianReserve.php?Librarian=$Librarian&Existing=Deleted');</script>");
  mysqli_close($conn);
}
if (isset($_POST['DeleteEdit'])) {
  $Librarian = $_POST['Librarian'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
  $sql = 'SELECT * FROM tblbooks WHERE BookId =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $BookId = $row["BookId"];
        $BookTitle = $row["BookTitle"];
        $BookAuthor = $row["BookAuthor"];
        $BookDescription = $row["BookDescription"];
        $BookPublishingDate = $row["PublishingDate"];
        $BookCompany = $row["PublishingCompany"];
        $sqli = "INSERT INTO tbldeleted (BookId, BookTitle, BookAuthor, BookDescription, BookPublishingDate, BookPublishingCompany) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookPublishingDate, $BookCompany);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblbooks WHERE BookId=' . $id);
        header("location: LibrarianEdit.php?Librarian=" . $_POST['Librarian']);
      
    }
    
    
  } else {
    echo "0";
  }
 
  }
  if ($chkarr) {
    echo ("<script>location.replace('LibrarianEdit.php?Librarian=$Librarian');</script>");
  }
  $conn->close();
  mysqli_close($conn);
}
if (isset($_POST['AddEdit'])) {
  $Librarian = $_POST['Librarian'];
  header("location: ReserveFormModal.php?Librarian=$Librarian");
}
if (isset($_POST['Returned'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE AccountId =" . $_POST['AccountId']);
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  $sql = 'SELECT * FROM tblborrowed WHERE AccountId=' . $_POST['AccountId'];
  $result = $conn->query($sql);
  foreach ($ids_array as $array) {
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $BookTitle = $row["BookTitle"];
        $BookAuthor = $row["BookAuthor"];
        $BookDescription = $row["BookDescription"];
        $BookPublishingDate = $row["BookPublishingDate"];
        $BookCompany = $row["BookPublishingCompany"];
        $sqli = "INSERT INTO tblbooks(BookTitle, BookAuthor, BookDescription, PublishingDate, PublishingCompany) VALUES (?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "sssss", $BookTitle, $BookAuthor, $BookDescription, $BookPublishingDate, $BookCompany);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        foreach ($ids_array as $array) {
          mysqli_query($conn, 'DELETE FROM tblborrowed WHERE BookId=' . $array);
        }
        header("location: LibrarianReservations.php?Librarian=" . $_GET['Librarian']);
      }
    }
    exit();
  }
  header("location: LibrarianReserve.php?Librarian=" . $_GET['Librarian']);
  $conn->close();
}
if (isset($_POST['Acquired'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE AccountId =" . $_POST['AccountId']);
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  foreach ($ids_array as $array) {
    $S = "1";
    $sqli = "UPDATE tblborrowed SET S = $S WHERE AccountId =" . $_POST['AccountId'];
    $sqlirun = mysqli_query($conn, $sqli);
    header("location: LibrarianReservations.php?Librarian=" . $_GET['Librarian']);
  }
  exit();
  $conn->close();
}
if(isset($_POST['SecondCancel'])){
  header("location: LibrarianReservations.php?Librarian=" . $_GET['Librarian']);
}
if (isset($_POST['UpdateABook'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $Title = $_POST["BookTitle"];
  $Author = $_POST["BookAuthor"];
  $Description = $_POST["BookDescription"];
  $Company = $_POST["PublishingCompany"];
  $Date = $_POST["from"];
  $sqli = "UPDATE tblbooks SET BookTitle=?, BookAuthor=?, BookDescription=?, PublishingDate=?, PublishingCompany=? WHERE tblbooks.BookId =" . $_GET['View'];
  $stmt = $conn->prepare($sqli);
  $stmt->bind_param('sssss', $Title, $Author, $Description, $Date, $Company);
  $stmt->execute();
  header("location: LibrarianEdit.php?Librarian=" . $_GET['Librarian']);
}
if (isset($_POST["Confirm"])) {
  $Librarian = $_POST["Librarian"];
  $from = $_POST["from"];
  $to = $_POST["to"];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblreserveticket WHERE AccountId = $Librarian;");
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  foreach ($ids_array as $array) {
    $dup = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE BookId = $array OR AccountId = $Librarian");
    if (mysqli_num_rows($dup) > 0) {
      header("location:LibrarianReserve.php?Librarian=$Librarian&Existing=Reservation");
    } else {
      $sql = 'SELECT * FROM tblreserveticket WHERE AccountId=' . $Librarian;
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
          $AccountId = $row["AccountId"];
          $AccountName = $row["AccountName"];
          $AccountO365 = $row["AccountO365"];
          $AccountNo = $row["AccountNo"];
          $BookId = $row["BookId"];
          $BookTitle = $row["BookTitle"];
          $BookAuthor = $row["BookAuthor"];
          $BookDescription = $row["BookDescription"];
          $BookPublishingDate = $row["BookPublishingDate"];
          $BookCompany = $row["BookPublishingCompany"];
          $sqli = "INSERT INTO tblborrowed (AccountId, AccountName, AccountO365, AccountNo, BookId, BookTitle, BookAuthor, BookDescription, BookPublishingCompany, BookPublishingDate, PickupDate, ReturnDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
          $stmt = mysqli_stmt_init($conn);
          if (!mysqli_stmt_prepare($stmt, $sqli)) {
            header("location: Register.php?error=stmtfailed");
            exit();
          }
          mysqli_stmt_bind_param($stmt, "ssssssssssss", $AccountId, $AccountName, $AccountO365, $AccountNo, $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookCompany, $BookPublishingDate, $from, $to);
          mysqli_stmt_execute($stmt);
          mysqli_stmt_close($stmt);
          foreach ($ids_array as $array) {
            mysqli_query($conn, 'DELETE FROM tblreserveticket WHERE BookId=' . $array);
            mysqli_query($conn, 'DELETE FROM tblbooks WHERE BookId=' . $array);
          }
          header("location: LibrarianReserve.php?Librarian=$Librarian&Existing=Success");
        }
      }
    }
    exit();
  }
  header("location: LibrarianReserve.php?Librarian=$Librarian");
  $conn->close();
}
if(isset($_POST['Register'])){
  $Librarian = $_POST['Librarian'];
  header("location: Register.php?Librarian=$Librarian");
}
if(isset($_POST['DeleteStudent'])){
  $Librarian = $_POST['Librarian'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
    
  $sql = 'SELECT * FROM tblaccounts WHERE Id =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $AccountId = $row["Id"];
        $AccountO365 = $row["O365"];
        $AccountName = $row["Name"];
        $AccountPassword = $row["Password"];
        $AccountContactNo = $row["ContactNo"];
        $AccountRole = $row["Role"];
        $sqli = "INSERT INTO tbldeleted (AccountId, AccountO365, AccountName, AccountPassword, AccountContactNo, AccountRole) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $AccountId, $AccountO365, $AccountName, $AccountPassword, $AccountContactNo, $AccountRole);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblaccounts WHERE Id=' . $id);
        header("location: LibrarianProfiles.php?Librarian=" . $_POST['Librarian']);
        
      
    }
    
  } else {
    echo "0";
  }
  }
  if ($chkarr) {
    echo ("<script>location.replace('LibrarianProfiles.php?Librarian=$Librarian');</script>");
  }
  $conn->close();
  mysqli_close($conn);
}
if(isset($_POST['DeleteLibrarian'])){
  $Librarian = $_POST['Librarian'];
  $id = $_POST['BookId'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $sql = 'SELECT * FROM tblaccounts WHERE Id =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $AccountId = $row["Id"];
        $AccountO365 = $row["O365"];
        $AccountName = $row["Name"];
        $AccountPassword = $row["Password"];
        $AccountContactNo = $row["ContactNo"];
        $AccountRole = $row["Role"];
        $sqli = "INSERT INTO tbldeleted (AccountId, AccountO365, AccountName, AccountPassword, AccountContactNo, AccountRole) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $AccountId, $AccountO365, $AccountName, $AccountPassword, $AccountContactNo, $AccountRole);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblaccounts WHERE Id=' . $id);
        header("location: LibrarianProfiles.php?Librarian=" . $_POST['Librarian']);
        exit();
      
    }
    
    $conn->close();
    mysqli_close($conn);
  } else {
    echo "0";
  }
    echo ("<script>location.replace('LibrarianProfiles.php?Librarian=$Librarian');</script>");
  mysqli_close($conn);
}