<?php
session_start();
if (!isset($_SESSION["Librarian"])) {
    header("location: Register.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Librarian</title>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/themes/base/jquery-ui.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
</head>
<style>
    @font-face {
        font-family: 'LouisBold';
        src: url('../Fonts/louis_george_cafe_bold-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe_bold-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: 'LouisRegular';
        src: url('../Fonts/louis_george_cafe-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }


    body {
        margin: 0;
    }

    .Container {
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "sidebar contentpage contentpage";
        grid-template-columns: 0.5fr 3.5fr;
        grid-template-rows: 9.5vh 90.5vh;
    }

    .Header {
        grid-area: topbar;
        background-color: #0b5793;
        display: flex;
        align-items: center;
    }

    .Header p {
        color: white;
        margin: 0px 0px 0px 5vh;
        font-size: 4vh;
        font-family: LouisBold;
    }

    .Sidebar {
        grid-area: sidebar;
        background-color: white;
        border-right: 1vh solid #f4d03f;
    }

    .SidebarContents {
        margin: 5vh 5vh 5vh 5vh;
        display: grid;
        height: 80.5vh;
        grid-template-areas:
            "AccountHead"
            "Selects"
            "Options";
        grid-template-rows: 1fr 2fr 1fr;
        grid-template-columns: 1fr;
    }

    .Account {
        grid-area: AccountHead;
        align-self: flex-start;
    }

    .SidebarAccountName {
        color: black;
        font-family: LouisRegular;
        font-size: 3.5vh;
        margin: 0;
        overflow: hidden;
        width: 6.5em;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .SidebarAccountEmail,
    .SidebarAccountContactNo {
        color: #000000;
        opacity: 50%;
        font-family: LouisRegular;
        font-size: 1.75vh;
        margin: 0;
        width: 13em;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .HROne {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 2vh 0vh 0vh 0vh;
    }

    .Buttons {
        height: 100%;
        grid-area: Selects;
    }

    .ButtonContainer {
        height: 100%;
        width: 100%;
    }

    .Button {
        display: flex;
        align-items: center;
        width: 100%;
        height: 7vh;
        font-size: 2.5vh;
        background: none;
        font-family: LouisRegular;
        outline: none;
        border: none;
    }

    .Button:hover {
        background: rgba(0, 0, 0, 0.05);
    }

    .HRTwo {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 0vh 0vh 2vh 0vh;
    }

    .Options {
        align-self: flex-end;
        grid-area: Options;
    }

    .Option {
        display: block;
        text-decoration: none;
        color: #0b5793;
        font-family: LouisRegular;
        font-size: 2vh;
        margin: 0;
    }


    .Search {
        grid-area: Second;
        display: flex;
        width: 100%;
        justify-content: flex-end;
    }

    .Searcher {
        grid-area: topbar;
        display: block;
        outline: none;
        font-family: LouisRegular;
        font-size: 3vh;
        border: 0.1vh solid #0b5793;
        width: 100%;
        background-color: white;
        color: #0b5793;
    }

    .Tables {
        overflow: hidden;
        overflow-y: auto;
        margin: 1vh;
        height: 71vh;
        grid-area: contentpage;
        display: grid;
        grid-template-areas:
            "Topp";
        grid-template-rows: 1fr;
    }

    .TablesTwo {
        overflow: hidden;
        overflow-y: auto;
        margin: 1vh;
        height: 71vh;
        grid-area: contentpage;
        display: grid;
        grid-template-areas:
            "Topp"
            "Bott";
        grid-template-rows: 1.75fr .25fr;
    }

    .BookTableContents {
        width: 100%;
        font-family: LouisRegular;
        overflow: hidden;
        overflow-y: scroll;
    }

    .BookTableContents td {
        text-align: center;
        font-size: 2vh;
        border-bottom: 0.1vh solid rgba(0, 0, 0, 0.5);
    }

    .BookTableDetail:hover {
        background-color: rgba(0, 0, 0, 0.02);
    }

    .BookTableContents th {
        background-color: rgba(0, 0, 0, 0.05);
        font-size: 1.75vh;
        font-family: LouisBold;
        font-weight: 900;
    }

    .BookTableContents td,
    th {
        text-align: center;
        padding: 1vh;
    }

    .Topp {
        overflow: hidden;
        overflow-y: auto;
        grid-area: Topp;
    }

    .ListLabel {
        font-family: LouisRegular;
        font-size: 3vh;
        margin: 0;
    }

    .List {
        font-size: 2vh;
        font-family: LouisRegular;
    }

    .Bott {
        grid-area: Bott;
        border-top: 0.1vh solid black;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
    }

    .BottTwo {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .Chk {
        margin: 1vh;
        width: 2vh;
        height: 2vh;
    }

    .checky {
        font-size: 2vh;
    }

    .Confirm,
    .Cancel {
        margin: 1vh;
        background: none;
        border: none;
        outline: none;
        color: white;
    }

    .Confirm {
        background-color: #0b5793;
        height: 4vh;
        font-size: 2vh;
        width: 100%;
    }

    .Confirm:hover {
        background-color: #446a88;
        transition: 0.25s ease-in-out;
    }

    .Cancel {
        background-color: #bc2c3c;
        height: 4vh;
        font-size: 2vh;
        width: 49%;
    }

    .Cancel:hover {
        background-color: #bd5d69;
        transition: 0.25s ease-in-out;
    }

    /*Cart*/
    .CartContentPage {
        display: flex;
        height: 90.5vh;
        background-color: rgba(0, 0, 0, 0.05);
    }

    .CartContentPageContents {
        box-shadow: 0vh 0vh 0.5vh rgba(0, 0, 0, 0.5);
        background-color: white;
        height: 82.5vh;
        width: 100%;
        margin: 4vh 4vh 4vh 4vh;
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "contentpage contentpage contentpage";
        grid-template-rows: 9.5vh 73vh;
    }

    .CartHeaders {
        background-color: rgba(0, 0, 0, 0.05);
        align-items: center;
        grid-area: topbar;
        display: grid;
        grid-template-areas:
            "First Second Third";
        grid-template-columns: 1fr 1fr 1fr;
        font-size: 3vh;
        padding-left: 2vh;
        font-family: LouisRegular;
        border-bottom: 0.5vh solid #0b5793;
    }

    .ReservationInfoBooks {
        font-family: LouisBold;
        font-size: 3vh;
        margin: 1vh;
    }

    .ReservationInfoBooksList {
        font-family: LouisRegular;
        font-size: 2vh;
        margin: 1.25vh;
    }

    .Acquired{
        color: #5cb85c;
    }

    .SecondConfirm{
        font-size: 1.5vh;
        background-color: #5cb85c;
        outline:none;
        border:0.1vh solid black;
        color:white;
        padding:0.5vh;
        border-radius: 0.5vh;
    }

    .SecondCancel{
        font-size: 1.5vh;
        background-color: #d9534f;
        outline:none;
        border:0.1vh solid black;
        color:white;
        padding:0.5vh;
        border-radius: 0.5vh;
    }

    .FirstConfirm{
        font-size: 1.5vh;
        background-color: #0275d8;
        outline:none;
        border:0.1vh solid black;
        color:white;
        padding:0.5vh;
        border-radius: 0.5vh;
    }

    .FirstCancel{
        font-size: 1.5vh;
        background-color: #d9534f;
        outline:none;
        border:0.1vh solid black;
        color:white;
        padding:0.5vh;
        border-radius: 0.5vh;
    }

    .SecondForm{
        display:flex;
        justify-content: space-evenly;
    }
</style>

<body>
    <script>
        function myFunction() {
            // Declare variables
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            // Loop through all table rows, and hide those who don't match the search query
            for (i = 0; i < tr.length; i++) {
                td1 = tr[i].getElementsByTagName("td")[0];
                td2 = tr[i].getElementsByTagName("td")[1];
                td3 = tr[i].getElementsByTagName("td")[2];
                td4 = tr[i].getElementsByTagName("td")[3];
                td5 = tr[i].getElementsByTagName("td")[4];
                td6 = tr[i].getElementsByTagName("td")[5];
                if (td1 && td2 && td3 && td4 && td5 && td6) {
                    if (td1.innerText.toUpperCase().indexOf(filter) > -1 || td2.innerText.toUpperCase().indexOf(filter) > -1 || td3.innerText.toUpperCase().indexOf(filter) > -1 || td4.innerText.toUpperCase().indexOf(filter) > -1 || td5.innerText.toUpperCase().indexOf(filter) > -1 || td6.innerText.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
        $(document).ready(function() {
            $("#Acquired").submit(function() {
                var d1 = $('#PickupDate').val();
                var d2 = $('#ReturnDate').val();

                var date1 = new Date(d1);
                var date2 = new Date(d2);

                var date1_ms = date1.getTime();
                var date2_ms = date2.getTime();

                var diff = date2_ms - date1_ms;

                // get days
                var days = diff / 1000 / 60 / 60 / 24;

                $('#Countdown').val(days);
            });
        });

        $('#Acquired').on('click', function() {

            var t = $(this).text();
            $(this).text('').append($('<input />', {
                'value': t
            }));
            $('input').focus();


        });
        function Alert(){
            var verify = prompt("Please enter your O365 email to confirm");
            var email = document.getElementById("SidebarAccountEmail").textContent;
            if(verify == email){
                return true;
            }
            else{
                return false;
            }
        }
    </script>
    <div class="MaxReso">
        <div class="Container">
            <?php require 'C:\xampp\htdocs\OLMS\Parts\LibHeader.php'; ?>
            <?php require 'C:\xampp\htdocs\OLMS\Parts\LibSidebar.php'; ?>
            <!--Cart-->
            <div id="CartContentPage" class="CartContentPage">
                <div class="CartContentPageContents">
                    <div class="CartHeaders">
                        Reservation Tickets
                        <div class="Search">

                            <input type="text" class="Searcher" placeholder="Search" id="myInput" onkeyup="myFunction()">
                        </div>
                    
                    </div>
                    <div class="Tables">
                        <div class="Topp">
                            <table class="BookTableContents" cellspacing="0" id="myTable">
                                <tr>
                                    <th>ACCOUNT</th>
                                    <th>CONTACT INFORMATION</th>
                                    <th>BOOK TITLE</th>
                                    <th>PICK UP DATE</th>
                                    <th>RETURN DATE</th>
                                    <th>STATUS</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                <?php
                                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                if ($conn->connect_error) {
                                    die("Connection failed:" . $conn->connect_error);
                                }
                                $ids_booktitle = array();
                                $ids_bookauthor = array();
                                $ids_bookdecription = array();
                                $ids_bookpublishingcompany = array();
                                $ids_bookpublishingdate = array();
                                $resultbook = mysqli_query($conn, "SELECT * FROM tblborrowed");
                                while ($rowbook = mysqli_fetch_array($resultbook)) {
                                    $ids_booktitle[] = $rowbook['BookTitle'];
                                    $ids_bookauthor[] = $rowbook['BookAuthor'];
                                    $ids_bookdescription[] = $rowbook['BookDescription'];
                                    $ids_bookpublishingcompany[] = $rowbook['BookPublishingCompany'];
                                    $ids_bookpublishingdate[] = $rowbook['BookPublishingDate'];
                                }

                                $sql = "SELECT * FROM tblborrowed";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {

                                ?>

                                        <tr class="BookTableDetail" name="View">
                                            <td><?php echo $row["AccountName"]; ?></td>
                                            <td><?php echo $row["AccountNo"]; ?><br><?php echo $row["AccountO365"]; ?></td>
                                            <td><?php echo $row["BookTitle"]; ?></td>
                                            <td id="PickupDate"><?php echo $row["PickupDate"]; ?></td>
                                            <td id="ReturnDate"><?php echo $row["ReturnDate"]; ?></td>
                                            <td id="Status"><?php if ($row["S"] == "0") {
                                                echo "NOT YET ACQUIRED";
                                                }
                                                else if($row["S"] == "1"){
                                                    echo "<p class='Acquired'>ACQUIRED<p>";
                                                }
                                            ?></td>
                                            <form action="All.inc.php?Librarian=<?php echo $_GET['Librarian']; ?>&View=<?php foreach ($ids_booktitle as $key => $value) {
                                                                                                    echo $value;
                                                                                                } ?>"  method="post">
                                                <td><?php if($row["S"] == "1"){

                                                }
                                                else{
                                                    echo '<input type="submit" class="FirstConfirm" onclick="return Alert()" value="Acquired" name="Acquired" id="Acquired">';
                                                }
                                                ?></td>
                                                <td><input type="submit" class="FirstCancel" value="Returned" onclick="return Alert()" formaction="All.inc.php?Librarian=<?php echo $_GET['Librarian']; ?>&View=<?php foreach ($ids_booktitle as $key => $value) {
                                                                                                    echo $value;
                                                                                                } ?>" formethod="post" name="Returned" id="Returned"></td>
                                                <input type="hidden" name="AccountId" value="<?php echo $row['AccountId']; ?>">
                                                <input type="hidden" name="BookTitle" value="<?php foreach ($ids_booktitle as $key => $value) {
                                                                                                    echo $value;
                                                                                                } ?>">
                                                <input type="hidden" name="BookAuthor" value="<?php foreach ($ids_bookauthor as $key => $value) {
                                                                                                    echo $value;
                                                                                                } ?>">
                                                <input type="hidden" name="BookDescription" value="<?php foreach ($ids_bookdescription as $key => $value) {
                                                                                                        echo $value;
                                                                                                    } ?>">
                                                <input type="hidden" name="BookPublishingCompany" value="<?php foreach ($ids_bookpublishingcompany as $key => $value) {
                                                                                                                echo $value;
                                                                                                            } ?>">
                                                <input type="hidden" name="BookPublishingDate" value="<?php foreach ($ids_bookpublishingdate as $key => $value) {
                                                                                                            echo $value;
                                                                                                        } ?>">

                                            </form>

                                        </tr>

                                <?php
                                    }
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>