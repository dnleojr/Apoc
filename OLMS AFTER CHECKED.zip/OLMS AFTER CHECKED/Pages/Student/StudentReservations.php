<?php
session_start();
if (!isset($_SESSION["Student"])) {
    header("location: Register.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student</title>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/themes/base/jquery-ui.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
</head>
<style>
    @font-face {
        font-family: 'LouisBold';
        src: url('../Fonts/louis_george_cafe_bold-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe_bold-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: 'LouisRegular';
        src: url('../Fonts/louis_george_cafe-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }


    body {
        margin: 0;
    }

    .Container {
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "sidebar contentpage contentpage";
        grid-template-columns: 0.5fr 3.5fr;
        grid-template-rows: 9.5vh 90.5vh;
    }

    .Header {
        grid-area: topbar;
        background-color: #0b5793;
        display: flex;
        align-items: center;
    }

    .Header p {
        color: white;
        margin: 0px 0px 0px 5vh;
        font-size: 4vh;
        font-family: LouisBold;
    }

    .Sidebar {
        grid-area: sidebar;
        background-color: white;
        border-right: 1vh solid #f4d03f;
    }

    .SidebarContents {
        margin: 5vh 5vh 5vh 5vh;
        display: grid;
        height: 80.5vh;
        grid-template-areas:
            "AccountHead"
            "Selects"
            "Options";
        grid-template-rows: 1fr 2fr 1fr;
        grid-template-columns: 1fr;
    }

    .Account {
        grid-area: AccountHead;
        align-self: flex-start;
    }

    .SidebarAccountName {
        color: black;
        font-family: LouisRegular;
        font-size: 3.5vh;
        margin: 0;
        overflow: hidden;
        width: 6.5em;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .SidebarAccountEmail,
    .SidebarAccountContactNo {
        color: #000000;
        opacity: 50%;
        font-family: LouisRegular;
        font-size: 1.75vh;
        margin: 0;
        width: 13em;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .HROne {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 2vh 0vh 0vh 0vh;
    }

    .Buttons {
        height: 100%;
        grid-area: Selects;
    }

    .ButtonContainer {
        height: 100%;
        width: 100%;
    }

    .Button {
        display: flex;
        align-items: center;
        width: 100%;
        height: 7vh;
        font-size: 2.5vh;
        background: none;
        font-family: LouisRegular;
        outline: none;
        border: none;
    }

    .Button:hover {
        background: rgba(0, 0, 0, 0.05);
    }

    .HRTwo {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 0vh 0vh 2vh 0vh;
    }

    .Options {
        align-self: flex-end;
        grid-area: Options;
    }

    .Option {
        display: block;
        text-decoration: none;
        color: #0b5793;
        font-family: LouisRegular;
        font-size: 2vh;
        margin: 0;
    }

    .Headers {
        background-color: rgba(0, 0, 0, 0.05);
        align-items: center;
        grid-area: topbar;
        display: grid;
        border-bottom: 0.5vh solid #0b5793;
    }

    .Searcher {
        grid-area: topbar;
        display: block;
        outline: none;
        font-family: LouisRegular;
        font-size: 3vh;
        border: 0.1vh solid #0b5793;
        width: 25vh;
        margin: 0vh 0vh 0vh 1vh;
        background-color: white;
        padding-left: 1vh;
        color: #0b5793;
    }

    .Tables {
        overflow: hidden;
        overflow-y: auto;
        margin: 1vh;
        height: 71vh;
        grid-area: contentpage;
        display: grid;
        grid-template-areas:
            "Topp"
            "Bott";
        grid-template-rows: 1.25fr .75fr;
    }
    .TablesTwo {
        overflow: hidden;
        overflow-y: auto;
        margin: 1vh;
        height: 71vh;
        grid-area: contentpage;
    }

    .BookTableContents {
        width: 100%;
        font-family: LouisRegular;
        overflow: hidden;
        overflow-y: scroll;
    }

    .BookTableContents td {
        font-size: 2vh;
        border-bottom: 0.1vh solid rgba(0, 0, 0, 0.5);
    }

    .BookTableDetail:hover {
        background-color: rgba(0, 0, 0, 0.02);
    }

    .BookTableContents th {
        background-color: rgba(0, 0, 0, 0.05);
        font-size: 1.75vh;
        font-family: LouisBold;
        font-weight: 900;
    }

    .BookTableContents td,
    th {
        text-align: left;
        padding: 1vh;
    }

    .Topp {
        overflow: hidden;
        overflow-y: auto;
        grid-area: Topp;
    }

    .ListLabel {
        font-family: LouisRegular;
        font-size: 3vh;
        margin: 0;
    }

    .List {
        font-size: 2vh;
        font-family: LouisRegular;
    }

    .Bott {
        grid-area: Bott;
        display: grid;
        grid-template-areas:
            "BottMidd"
            "BottBott";
        grid-template-rows: 1fr 1fr;
    }

    .DateLabel {
        margin: 0;
        font-size: 2vh;
        font-family: LouisRegular;
    }

    .daterange {
        width: 50%;
        text-align: center;
        outline: none;
        height: 20%;
    }

    .BottMidd {
        grid-area: BottMidd;
        display: grid;
        grid-template-areas:
            "Left Right";
        grid-template-columns: 1fr 1fr;
        border-top: 0.1vh solid black;
    }

    .MiddOne {
        grid-area: Left;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .MiddTwo {
        grid-area: Right;
        display: grid;
        grid-template-areas:
            "Lefty Righty";
        grid-template-columns: 1fr 1fr;
    }

    .MiddTwoLeft {
        grid-area: Lefty;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .MiddTwoLeft p {
        font-size: 2.5vh;
        margin: .5vh;
    }

    .MiddTwoRight {
        grid-area: Righty;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .datepickers{
        border: 0.1vh solid black;
        font-size: 2vh;
    }

    .form {
        display: flex;
        justify-content: center;
    }

    .MiddTwoRight input {
        outline: none;
        margin: .5vh;
    }

    .AccountInfo {
        margin: 0;
        font-size: 2.5vh;
        color: grey;
        font-family: LouisRegular;
    }

    .BottBott {
        grid-area: BottBott;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .BottTwo {
        display: flex;
        flex-direction: row;
        justify-content: center;
    }

    .Chk {
        margin: 1vh;
        width: 2vh;
        height: 2vh;
    }

    .checky{
        font-size: 2vh;
    }

    .Confirm,
    .Cancel {
        margin: 1vh;
        background: none;
        border: none;
        outline: none;
        color: white;
    }

    .Confirm {
        background-color: #d9534f;
        height: 4vh;
        font-size: 2vh;
        width: 100%;
    }

    .Confirm:hover {
        opacity:75%;
        transition: 0.25s ease-in-out;
    }

    .Cancel {
        background-color: #bc2c3c;
        height: 4vh;
        font-size: 2vh;
        width: 49%;
    }

    .Cancel:hover {
        background-color: #bd5d69;
        transition: 0.25s ease-in-out;
    }

    /*Cart*/
    .CartContentPage {
        display: flex;
        height: 90.5vh;
        background-color: rgba(0, 0, 0, 0.05);
    }

    .CartContentPageContents {
        box-shadow: 0vh 0vh 0.5vh rgba(0, 0, 0, 0.5);
        background-color: white;
        height: 82.5vh;
        width: 100%;
        margin: 4vh 4vh 4vh 4vh;
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "contentpage contentpage contentpage";
        grid-template-rows: 9.5vh 73vh;
    }

    .CartContentPageContentsTwo {
        box-shadow: 0vh 0vh 0.5vh rgba(0, 0, 0, 0.5);
        background-color: white;
        height: 82.5vh;
        width: 25%;
        margin: 4vh 4vh 4vh 1vh;
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "contentpage contentpage contentpage";
        grid-template-rows: 9.5vh 73vh;
    }

    .CartHeaders {
        background-color: rgba(0, 0, 0, 0.05);
        align-items: center;
        grid-area: topbar;
        display: flex;
        font-size: 3vh;
        padding-left: 2vh;
        font-family: LouisRegular;
        justify-content: space-between;
        border-bottom: 0.5vh solid #0b5793;
    }

    .Remarks{
        display:flex;
        color:red;
        justify-content:flex-end;
        width: 80%;
        margin-right:2vh;
    }

    .Remarksgreen{
        display:flex;
        color:green;
        justify-content:flex-end;
        width: 80%;
        margin-right:2vh;
    }

    .Reminders{
        width: fit-content;
        border-bottom: 0.1vh solid black;
        margin: 1vh;
    }
    .Reminders p{
        font-size:2vh;
    }

    .Delete{
        font-size: 1.5vh;
        background-color: #d9534f;
        outline:none;
        border:0.1vh solid black;
        color:white;
        padding:0.5vh;
        border-radius: 0.5vh;
    }
</style>

<body onload="Display();">
    <script>
        function myFunction() {
            // Declare variables
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            // Loop through all table rows, and hide those who don't match the search query
            for (i = 0; i < tr.length; i++) {
                td1 = tr[i].getElementsByTagName("td")[0];
                td2 = tr[i].getElementsByTagName("td")[1];
                td3 = tr[i].getElementsByTagName("td")[2];
                td4 = tr[i].getElementsByTagName("td")[3];
                td5 = tr[i].getElementsByTagName("td")[4];
                td6 = tr[i].getElementsByTagName("td")[5];
                if (td1 && td2 && td3 && td4 && td5 && td6) {
                    if (td1.innerText.toUpperCase().indexOf(filter) > -1 || td2.innerText.toUpperCase().indexOf(filter) > -1 || td3.innerText.toUpperCase().indexOf(filter) > -1 || td4.innerText.toUpperCase().indexOf(filter) > -1 || td5.innerText.toUpperCase().indexOf(filter) > -1 || td6.innerText.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
        $(document).ready(function() {
            $("#Acquired").submit(function() {
                var d1 = $('#PickupDate').val();
                var d2 = $('#ReturnDate').val();

                var date1 = new Date(d1);
                var date2 = new Date(d2);

                var date1_ms = date1.getTime();
                var date2_ms = date2.getTime();

                var diff = date2_ms - date1_ms;

                // get days
                var days = diff / 1000 / 60 / 60 / 24;

                $('#Countdown').val(days);
            });
        });

        $('#Acquired').on('click', function() {

            var t = $(this).text();
            $(this).text('').append($('<input />', {
                'value': t
            }));
            $('input').focus();


        });
        function Alert(){
            var verify = prompt("Please enter your O365 email to confirm");
            var email = document.getElementById("SidebarAccountEmail").textContent;
            if(verify == email){
                return true;
            }
            else{
                return false;
            }
        }

        
        function Display(){
            var a = $("#Status").val();
            var b = "Acquired";
            var c = "Not yet acquired";
            if(a==c){
                $("#BottBot").show();
            }
            else{
                $("#BottBot").hide();
            }
        }
        

    </script>
    <div class="MaxReso">
        <div class="Container">
            <?php require 'C:\xampp\htdocs\OLMS\Parts\StudentHeader.php'; ?>
            <?php require 'C:\xampp\htdocs\OLMS\Parts\StudentSidebar.php'; ?>
            <!--Cart-->
            <div id="CartContentPage" class="CartContentPage">
                <div class="CartContentPageContents">
                    <div class="CartHeaders">
                        My reservation
                        <?php
                  if (isset($_GET["Existing"])) {
                    if ($_GET["Existing"] == "Reservation") {
                      echo "<p class='Remarks'>You already have an existing reservation</p>";
                    }
                    else if ($_GET["Existing"] == "Deleted") {
                        echo "<p class='Remarks'>Reservation cancelled</p>";
                      }
                      else if ($_GET["Existing"] == "Success") {
                        echo "<p class='Remarksgreen'>Book/s reserved</p>";
                      }
                    
                  }
                ?>
                    </div>
                    
                        <div class="Tables">
                        <div class="Topp">
                            <table class="BookTableContents" cellspacing="0" id="myTable">
                                <tr>
                                    <th>TITLE</th>
                                    <th>AUTHOR</th>
                                    <th>PUBLISHING COMPANY</th>
                                    <th>DATE PUBLISHED</th>
                                </tr>
                                <?php
                                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                if ($conn->connect_error) {
                                    die("Connection failed:" . $conn->connect_error);
                                }
                                $sql = "SELECT * FROM tblborrowed WHERE AccountId =" . $_GET['Student'];
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                ?>  
                                        
                                        <tr class="BookTableDetail" name="View" value="<?php echo $row['BookId'];?>">
                                            <td><?php echo $row["BookTitle"]; ?></td>
                                            <td><?php echo $row["BookAuthor"]; ?></td>
                                            <td><?php echo $row["BookPublishingCompany"]; ?></td>
                                            <td><?php echo $row["BookPublishingDate"]; ?></td>
                                            
                                            
                                        </tr>
                                        
                                <?php
                                    }
                                    
                                }
                                ?>
                            </table>
                        </div>
                        <div class="Bott">
                            <div class="BottMidd">
                                <div class="MiddOne">
                                    <?php
                                    $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                    if ($conn->connect_error) {
                                        die("Connection failed:" . $conn->connect_error);
                                    }
                                    $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Student'];
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        
                                        while ($row = $result->fetch_assoc()) {
                                            echo '<p class="AccountInfo">' . $row["Name"] . '</p>';
                                            echo '<p class="AccountInfo">' . $row["O365"] . '</p>';
                                            echo '<p class="AccountInfo">' . $row["ContactNo"] . '</p>';
                                        }
                                    } else {
                                        echo "0 result";
                                    }
                                    $conn->close();
                                    ?>
                                </div>
                                <form action="All.inc.php" method="post" class="form">
                                    <div class="MiddTwo">
                                        <div class="MiddTwoLeft">
                                            <p class="DateLabel">Pick up date:</p>
                                            <p class="DateLabel">Return date:</p>
                                            <p class="DateLabel">Reservation Status:</p>
                                        </div>
                                        <div class="MiddTwoRight">
                                        <?php
                                        $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                        if ($conn->connect_error) {
                                            die("Connection failed:" . $conn->connect_error);
                                        }
                                        $sql = "SELECT DISTINCT S, PickupDate, ReturnDate FROM tblborrowed WHERE AccountId =" . $_GET['Student'];
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                        ?>
                                            <input type="date" id="from" name="from" class="datepickers" value="<?php echo $row['PickupDate'];?>" disabled/>
                                            <input type="date" id="to" name="to" class="datepickers" value="<?php echo $row['ReturnDate'];?>" disabled/>
                                            <input type="text" name="Satus" id="Status" class="datepickers" value="<?php if ($row['S'] == "0") {
                                                echo "Not yet acquired";
                                                
                                            }
                                            else{
                                                echo "Acquired";
                                            }?>" disabled/>

                                            <?php
                                            }
                                        }
                                            ?>
                                            <script>
                                                $("#from").datepicker({
                                                    dateFormat: 'yy-mm-dd',
                                                    changeMonth: true,
                                                    minDate: new Date(),
                                                    maxDate: '+2y',
                                                    onSelect: function(date) {

                                                        var selectedDate = new Date(date);
                                                        var msecsInADay = 86400000;
                                                        var endDateone = new Date(selectedDate.getTime() +
                                                            msecsInADay * 2);
                                                        var endDatetwo = new Date(selectedDate.getTime() +
                                                            msecsInADay * 30);

                                                        //Set Minimum Date of EndDatePicker After Selected Date of StartDatePicker
                                                        $("#to").datepicker("option", "minDate", endDateone);
                                                        $("#to").datepicker("option", "maxDate", endDatetwo);

                                                    }
                                                });

                                                $("#to").datepicker({
                                                    dateFormat: 'yy-mm-dd',
                                                    changeMonth: true,
                                                    minDate: new Date()
                                                });

                                                function EnabledRemoveButton(check) {
                                                    var confirm = document.getElementById("Confirm");
                                                    confirm.disabled = check.checked ? false : true;
                                                }
                                            </script>
                                        </div>
                                    </div>
                            </div>
                            <div class="BottBott" id="BottBot">
                                <div class="BottOne">
                                <input type="checkbox" class="Chk" name="check" id="check" onclick="EnabledRemoveButton(this);" required>
                                <label class="checky">Check to enable cancel button.</label>
                                </div>
                                <div class="BottTwo" id="BottTwo"> 
                                    
                                        <input type="submit" class="Confirm" formaction="All.inc.php" formmethod="post" onclick="return Alert()" name="DeleteReservations" id="Confirm" onclick="return Alert();" value="Cancel reservation" disabled>
                                        <input type="hidden" name="Student" id="Student" value="<?php echo $_GET['Student']; ?>">
                                        
                                    
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>