<?php
if (isset($_POST['Checkout'])) {
  $UserId = $_POST['Student'];
  $BookkId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $sql = 'SELECT * FROM tblaccounts WHERE Id=' . $_POST['Student'];
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $dup = mysqli_query($conn, "SELECT * FROM tblreserveticket WHERE BookId = $BookkId AND AccountId = $UserId");
      if (mysqli_num_rows($dup) > 0) {
        header("location: StudentBooks.php?Student=$UserId");
      } else {
        $sqll = 'SELECT * FROM tblbooks WHERE BookId=' . $_POST['View'];
  $resultt = $conn->query($sqll);
  if ($resultt->num_rows > 0) {
    while ($roww = $resultt->fetch_assoc()) {
        $AccountId = $row["Id"];
        $AccountName = $row["Name"];
        $AccountO365 = $row["O365"];
        $AccountNo = $row["ContactNo"];
        $BookId = $roww["BookId"];
        $BookTitle = $roww["BookTitle"];
        $BookAuthor = $roww["BookAuthor"];
        $BookDescription = $roww["BookDescription"];
        $BookPublishingDate = $roww["PublishingDate"];
        $BookCompany = $roww["PublishingCompany"];
        $sqli = "INSERT INTO tblreserveticket (AccountId, AccountName, AccountO365, AccountNo, BookId, BookTitle, BookAuthor, BookDescription, BookPublishingCompany, BookPublishingDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssssssss", $AccountId, $AccountName, $AccountO365, $AccountNo, $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookCompany, $BookPublishingDate);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: StudentBooks.php?Student=" . $_POST['Student']);
        exit();
      }
    }
      }
    }
    $conn->close();
    mysqli_close($conn);
  } else {
    echo "0";
  }
  echo "1";
}
if (isset($_POST['Remove'])) {
  $Student = $_POST['Student'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
    mysqli_query($conn, 'DELETE FROM tblcart WHERE BookId=' . $id);
  }
  if ($chkarr) {
    echo ("<script>location.replace('StudentCart.php?Student=$Student');</script>");
  }
  mysqli_close($conn);
}
if (isset($_POST['Delete'])) {
  $Student = $_POST['Student'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  mysqli_query($conn, 'DELETE FROM tblreserveticket WHERE BookId=' . $BookId);
  echo ("<script>location.replace('StudentReserve.php?Student=$Student&Existing=Deleted');</script>");
  mysqli_close($conn);
}
























if (isset($_POST['DeleteReservations'])) {
  $Student = $_POST['Student'];
  $BookId = $_POST['Student'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $sql = 'SELECT * FROM tblborrowed WHERE AccountId =' .$BookId;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $BookTitle = $row["BookTitle"];
        $BookAuthor = $row["BookAuthor"];
        $BookDescription = $row["BookDescription"];
        $BookPublishingDate = $row["BookPublishingDate"];
        $BookCompany = $row["BookPublishingCompany"];
        $sqli = "INSERT INTO tblbooks (BookTitle, BookAuthor, BookDescription, PublishingDate, PublishingCompany) VALUES (?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "sssss", $BookTitle, $BookAuthor, $BookDescription, $BookPublishingDate, $BookCompany);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblborrowed WHERE AccountId=' . $Student);
        echo ("<script>location.replace('StudentReservations.php?Student=$Student&Existing=Deleted');</script>");
      
    }
    
    
  } else {
    echo "0";
  }
 

  mysqli_close($conn);
}
























if (isset($_POST['DeleteEdit'])) {
  $Student = $_POST['Student'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
  $sql = 'SELECT * FROM tblbooks WHERE BookId =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $BookId = $row["BookId"];
        $BookTitle = $row["BookTitle"];
        $BookAuthor = $row["BookAuthor"];
        $BookDescription = $row["BookDescription"];
        $BookPublishingDate = $row["PublishingDate"];
        $BookCompany = $row["PublishingCompany"];
        $sqli = "INSERT INTO tbldeleted (BookId, BookTitle, BookAuthor, BookDescription, BookPublishingDate, BookPublishingCompany) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookPublishingDate, $BookCompany);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblbooks WHERE BookId=' . $id);
        header("location: StudentEdit.php?Student=" . $_POST['Student']);
      
    }
    
    
  } else {
    echo "0";
  }
 
  }
  if ($chkarr) {
    echo ("<script>location.replace('StudentEdit.php?Student=$Student');</script>");
  }
  $conn->close();
  mysqli_close($conn);
}
if (isset($_POST['AddEdit'])) {
  $Student = $_POST['Student'];
  header("location: ReserveFormModal.php?Student=$Student");
}
if (isset($_POST['Returned'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE AccountId =" . $_POST['Student']);
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  $sql = 'SELECT * FROM tblborrowed WHERE AccountId=' . $_POST['Student'];
  $result = $conn->query($sql);
  foreach ($ids_array as $array) {
    if ($result->num_rows > 0) {
      while ($row = mysqli_fetch_assoc($result)) {
        $BookId = $row["BookId"];
        $BookTitle = $row["BookTitle"];
        $BookAuthor = $row["BookAuthor"];
        $BookDescription = $row["BookDescription"];
        $BookPublishingDate = $row["BookPublishingDate"];
        $BookCompany = $row["BookPublishingCompany"];
        $sqli = "INSERT INTO tblbooks(BookId, BookTitle, BookAuthor, BookDescription, PublishingDate, PublishingCompany) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookPublishingDate, $BookCompany);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        foreach ($ids_array as $array) {
          mysqli_query($conn, 'DELETE FROM tblborrowed WHERE BookId=' . $array);
          mysqli_query($conn, 'DELETE FROM tblreserveticket WHERE BookId=' . $array);
        }
        header("location: StudentReservations.php?Student=" . $_POST['Student']);
      }
    }
    exit();
  }
  header("location: StudentReserve.php?Student=" . $_POST['Student']);
  $conn->close();
}
if (isset($_POST['Acquired'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE AccountId =" . $_POST['Student']);
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  foreach ($ids_array as $array) {
    $S = "1";
    $sqli = "UPDATE tblborrowed SET S = $S WHERE AccountId =" . $_POST['Student'];
    $sqlirun = mysqli_query($conn, $sqli);
    header("location: StudentReservations.php?Student=" . $_POST['Student']);
  }
  exit();
  $conn->close();
}
if(isset($_POST['SecondCancel'])){
  header("location: StudentReservations.php?Student=" . $_GET['Student']);
}
if (isset($_POST['UpdateABook'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $Title = $_POST["BookTitle"];
  $Author = $_POST["BookAuthor"];
  $Description = $_POST["BookDescription"];
  $Company = $_POST["PublishingCompany"];
  $Date = $_POST["from"];
  $sqli = "UPDATE tblbooks SET BookTitle=?, BookAuthor=?, BookDescription=?, PublishingDate=?, PublishingCompany=? WHERE tblbooks.BookId =" . $_GET['View'];
  $stmt = $conn->prepare($sqli);
  $stmt->bind_param('sssss', $Title, $Author, $Description, $Date, $Company);
  $stmt->execute();
  header("location: StudentEdit.php?Student=" . $_GET['Student']);
}
if (isset($_POST["Confirm"])) {
  $Student = $_POST["Student"];
  $from = $_POST["from"];
  $to = $_POST["to"];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblreserveticket WHERE AccountId = $Student;");
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  foreach ($ids_array as $array) {
    $dup = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE BookId = $array OR AccountId = $Student");
    if (mysqli_num_rows($dup) > 0) {
      header("location:StudentReserve.php?Student=$Student&Existing=Reservation");
    } else {
      $sql = 'SELECT * FROM tblreserveticket WHERE AccountId=' . $Student;
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
          $AccountId = $row["AccountId"];
          $AccountName = $row["AccountName"];
          $AccountO365 = $row["AccountO365"];
          $AccountNo = $row["AccountNo"];
          $BookId = $row["BookId"];
          $BookTitle = $row["BookTitle"];
          $BookAuthor = $row["BookAuthor"];
          $BookDescription = $row["BookDescription"];
          $BookPublishingDate = $row["BookPublishingDate"];
          $BookCompany = $row["BookPublishingCompany"];
          $sqli = "INSERT INTO tblborrowed (AccountId, AccountName, AccountO365, AccountNo, BookId, BookTitle, BookAuthor, BookDescription, BookPublishingCompany, BookPublishingDate, PickupDate, ReturnDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
          $stmt = mysqli_stmt_init($conn);
          if (!mysqli_stmt_prepare($stmt, $sqli)) {
            header("location: Register.php?error=stmtfailed");
            exit();
          }
          mysqli_stmt_bind_param($stmt, "ssssssssssss", $AccountId, $AccountName, $AccountO365, $AccountNo, $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookCompany, $BookPublishingDate, $from, $to);
          mysqli_stmt_execute($stmt);
          mysqli_stmt_close($stmt);
          foreach ($ids_array as $array) {
            mysqli_query($conn, 'DELETE FROM tblreserveticket WHERE BookId=' . $array);
            mysqli_query($conn, 'DELETE FROM tblbooks WHERE BookId=' . $array);
          }
          header("location: StudentReserve.php?Student=$Student&Existing=Success");
        }
      }
    }
    exit();
  }
  header("location: StudentReserve.php?Student=$Student");
  $conn->close();
}
if(isset($_POST['Register'])){
  $Student = $_POST['Student'];
  header("location: Register.php?Student=$Student");
}
if(isset($_POST['DeleteStudent'])){
  $Student = $_POST['Student'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
    
  $sql = 'SELECT * FROM tblaccounts WHERE Id =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $AccountId = $row["Id"];
        $AccountO365 = $row["O365"];
        $AccountName = $row["Name"];
        $AccountPassword = $row["Password"];
        $AccountContactNo = $row["ContactNo"];
        $AccountRole = $row["Role"];
        $sqli = "INSERT INTO tbldeleted (AccountId, AccountO365, AccountName, AccountPassword, AccountContactNo, AccountRole) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $AccountId, $AccountO365, $AccountName, $AccountPassword, $AccountContactNo, $AccountRole);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblaccounts WHERE Id=' . $id);
        header("location: StudentProfiles.php?Student=" . $_POST['Student']);
        
      
    }
    
  } else {
    echo "0";
  }
  }
  if ($chkarr) {
    echo ("<script>location.replace('StudentProfiles.php?Student=$Student');</script>");
  }
  $conn->close();
  mysqli_close($conn);
}
if(isset($_POST['DeleteStudent'])){
  $Student = $_POST['Student'];
  $id = $_POST['BookId'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $sql = 'SELECT * FROM tblaccounts WHERE Id =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $AccountId = $row["Id"];
        $AccountO365 = $row["O365"];
        $AccountName = $row["Name"];
        $AccountPassword = $row["Password"];
        $AccountContactNo = $row["ContactNo"];
        $AccountRole = $row["Role"];
        $sqli = "INSERT INTO tbldeleted (AccountId, AccountO365, AccountName, AccountPassword, AccountContactNo, AccountRole) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $AccountId, $AccountO365, $AccountName, $AccountPassword, $AccountContactNo, $AccountRole);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblaccounts WHERE Id=' . $id);
        header("location: StudentProfiles.php?Student=" . $_POST['Student']);
        exit();
      
    }
    
    $conn->close();
    mysqli_close($conn);
  } else {
    echo "0";
  }
    echo ("<script>location.replace('StudentProfiles.php?Student=$Student');</script>");
  mysqli_close($conn);
}