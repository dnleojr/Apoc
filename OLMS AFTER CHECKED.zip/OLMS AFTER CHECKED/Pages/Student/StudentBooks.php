<?php
session_start();
if (!isset($_SESSION["Student"])) {
    header("location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Student</title>
</head>
<style>
    @font-face {
        font-family: 'LouisBold';
        src: url('../Fonts/louis_george_cafe_bold-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe_bold-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: 'LouisRegular';
        src: url('../Fonts/louis_george_cafe-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }

    body {
        margin: 0;
    }

    .Container {
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "sidebar contentpage contentpage";
        grid-template-columns: 0.5fr 3.5fr;
        grid-template-rows: 9.5vh 90.5vh;
    }

    .Header {
        grid-area: topbar;
        background-color: #0b5793;
        display: flex;
        align-items: center;
    }

    .Header p {
        color: white;
        margin: 0px 0px 0px 5vh;
        font-size: 4vh;
        font-family: LouisBold;
    }

    .Sidebar {
        grid-area: sidebar;
        background-color: white;
        border-right: 1vh solid #f4d03f;
    }

    .SidebarContents {
        margin: 5vh 5vh 5vh 5vh;
        display: grid;
        height: 80.5vh;
        grid-template-areas:
            "AccountHead"
            "Selects"
            "Options";
        grid-template-rows: 1fr 2fr 1fr;
        grid-template-columns: 1fr;
    }

    .Account {
        grid-area: AccountHead;
        align-self: flex-start;
    }

    .SidebarAccountName {
        color: black;
        font-family: LouisRegular;
        font-size: 3.5vh;
        margin: 0;
        overflow: hidden;
        width: 6.5em;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .SidebarAccountEmail,
    .SidebarAccountContactNo {
        color: #000000;
        opacity: 50%;
        font-family: LouisRegular;
        font-size: 1.75vh;
        margin: 0;
        width: 13em;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .HROne {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 2vh 0vh 0vh 0vh;
    }

    .Buttons {
        height: 100%;
        grid-area: Selects;
    }

    .ButtonContainer {
        height: 100%;
        width: 100%;
    }

    .Button {
        display: flex;
        align-items: center;
        width: 100%;
        height: 7vh;
        font-size: 2.5vh;
        background: none;
        font-family: LouisRegular;
        outline: none;
        border: none;
    }

    .Button:hover {
        background: rgba(0, 0, 0, 0.05);
    }

    .HRTwo {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 0vh 0vh 2vh 0vh;
    }

    .Options {
        align-self: flex-end;
        grid-area: Options;
    }

    .Option {
        display: block;
        text-decoration: none;
        color: #0b5793;
        font-family: LouisRegular;
        font-size: 2vh;
        margin: 0;
    }

    .ContentPage {
        height: 90.5vh;
        display: block;
        background-color: rgba(0, 0, 0, 0.05);
    }

    .ContentPageContents {
        box-shadow: 0vh 0vh 0.5vh rgba(0, 0, 0, 0.5);
        background-color: white;
        height: 82.5vh;
        margin: 4vh;
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "contentpage contentpage contentpage";
        grid-template-rows: 9.5vh 73vh;
    }

    .Headers {
        background-color: rgba(0, 0, 0, 0.05);
        align-items: center;
        grid-area: topbar;
        display: grid;
        grid-template-areas:
            "First Second Third";
        grid-template-columns: 1fr 1fr 1fr;
        font-size: 3vh;
        padding-left: 2vh;
        font-family: LouisRegular;
        border-bottom: 0.5vh solid #0b5793;
    }

    .Search {
        grid-area: Second;
        display: flex;
        width: 100%;
        justify-content: flex-end;
    }

    .Searcher {
        grid-area: topbar;
        display: block;
        outline: none;
        font-family: LouisRegular;
        font-size: 3vh;
        border: 0.1vh solid #0b5793;
        width: 100%;
        background-color: white;
        color: #0b5793;
    }

    .Tables {
        overflow: hidden;
        overflow-y: auto;
        position: relative;
        position: relative;
        margin: 1vh;
        grid-area: contentpage;
    }

    .BookTable {
        width: 100%;
    }

    .BookTableContents {
        width: 100%;
        text-align: left;
        font-family: LouisRegular;
    }

    .BookTableContents td {
        font-size: 2.5vh;
        border-bottom: 0.1vh solid rgba(0, 0, 0, 0.5);
    }

    .BookTableDetail:hover {
        background-color: rgba(0, 0, 0, 0.02);
    }

    .BookTableContents th {
        background-color: rgba(0, 0, 0, 0.05);
        font-size: 1.75vh;
        font-family: LouisBold;
        font-weight: 900;
    }

    .BookTableContents td,
    th {
        padding: 1vh;
    }
</style>

<body>
    <script>
        function myFunction() {
            // Declare variables
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            // Loop through all table rows, and hide those who don't match the search query
            for (i = 0; i < tr.length; i++) {
                td1 = tr[i].getElementsByTagName("td")[0];
                td2 = tr[i].getElementsByTagName("td")[1];
                td3 = tr[i].getElementsByTagName("td")[2];
                td4 = tr[i].getElementsByTagName("td")[3];
                if (td1 && td2 && td3 && td4) {
                    if (td1.innerText.toUpperCase().indexOf(filter) > -1 || td2.innerText.toUpperCase().indexOf(filter) > -1 || td3.innerText.toUpperCase().indexOf(filter) > -1 || td4.innerText.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
    <div class="MaxReso">
        <div class="Container">
            <?php require 'C:\xampp\htdocs\OLMS\Parts\StudentHeader.php'; ?>
            <?php require 'C:\xampp\htdocs\OLMS\Parts\StudentSidebar.php'; ?>
            <div id="BookContentPage" class="ContentPage">
                <div class="ContentPageContents">
                    <div class="Headers">
                        Books
                        <div class="Search">

                            <input type="text" class="Searcher" placeholder="Search" id="myInput" onkeyup="myFunction()">
                        </div>
                    </div>
                    <div class="Tables">
                        <!--Book Section-->
                        <div class="BookTable">
                            <table class="BookTableContents" cellspacing="0" id="myTable">
                                <tr>
                                    <th>TITLE</th>
                                    <th>AUTHOR</th>
                                    <th>PUBLISHING COMPANY</th>
                                    <th>DATE PUBLISHED</th>
                                </tr>
                                <?php
                                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                if ($conn->connect_error) {
                                    die("Connection failed:" . $conn->connect_error);
                                }
                                $sql = "SELECT * from tblbooks";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                ?>
                                        <form method="get">
                                            <tr class="BookTableDetail" onclick="location.replace('Modal.php?View=<?php echo $row['BookId']; ?>&Student=<?php echo $_GET['Student']; ?>');" name="View" value="<?php echo $row['BookId']; ?>">
                                        </form>
                                        <td><?php echo $row["BookTitle"]; ?></td>
                                        <td><?php echo $row["BookAuthor"]; ?></td>
                                        <td><?php echo $row["PublishingCompany"]; ?></td>
                                        <td><?php echo $row["PublishingDate"]; ?></td>
                                        </tr>
                                <?php
                                    }
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>