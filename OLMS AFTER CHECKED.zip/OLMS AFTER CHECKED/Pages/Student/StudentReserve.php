<?php
session_start();
if (!isset($_SESSION["Student"])) {
    header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student</title>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/themes/base/jquery-ui.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
</head>
<style>
    @font-face {
        font-family: 'LouisBold';
        src: url('../Fonts/louis_george_cafe_bold-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe_bold-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: 'LouisRegular';
        src: url('../Fonts/louis_george_cafe-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }

    body {
        margin: 0;
    }

    .Container {
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "sidebar contentpage contentpage";
        grid-template-columns: 0.5fr 3.5fr;
        grid-template-rows: 9.5vh 90.5vh;
    }

    .Header {
        grid-area: topbar;
        background-color: #0b5793;
        display: flex;
        align-items: center;
    }

    .Header p {
        color: white;
        margin: 0px 0px 0px 5vh;
        font-size: 4vh;
        font-family: LouisBold;
    }

    .Sidebar {
        grid-area: sidebar;
        background-color: white;
        border-right: 1vh solid #f4d03f;
    }

    .SidebarContents {
        margin: 5vh 5vh 5vh 5vh;
        display: grid;
        height: 80.5vh;
        grid-template-areas:
            "AccountHead"
            "Selects"
            "Options";
        grid-template-rows: 1fr 2fr 1fr;
        grid-template-columns: 1fr;
    }

    .Account {
        grid-area: AccountHead;
        align-self: flex-start;
    }

    .SidebarAccountName {
        color: black;
        font-family: LouisRegular;
        font-size: 3.5vh;
        margin: 0;
        overflow: hidden;
        width: 6.5em;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .SidebarAccountEmail,
    .SidebarAccountContactNo {
        color: #000000;
        opacity: 50%;
        font-family: LouisRegular;
        font-size: 1.75vh;
        margin: 0;
        width: 13em;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .HROne {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 2vh 0vh 0vh 0vh;
    }

    .Buttons {
        height: 100%;
        grid-area: Selects;
    }

    .ButtonContainer {
        height: 100%;
        width: 100%;
    }

    .Button {
        display: flex;
        align-items: center;
        width: 100%;
        height: 7vh;
        font-size: 2.5vh;
        background: none;
        font-family: LouisRegular;
        outline: none;
        border: none;
    }

    .Button:hover {
        background: rgba(0, 0, 0, 0.05);
    }

    .HRTwo {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 0vh 0vh 2vh 0vh;
    }

    .Options {
        align-self: flex-end;
        grid-area: Options;
    }

    .Option {
        display: block;
        text-decoration: none;
        color: #0b5793;
        font-family: LouisRegular;
        font-size: 2vh;
        margin: 0;
    }

    .Headers {
        background-color: rgba(0, 0, 0, 0.05);
        align-items: center;
        grid-area: topbar;
        display: grid;
        border-bottom: 0.5vh solid #0b5793;
    }

    .Searcher {
        grid-area: topbar;
        display: block;
        outline: none;
        font-family: LouisRegular;
        font-size: 3vh;
        border: 0.1vh solid #0b5793;
        width: 25vh;
        margin: 0vh 0vh 0vh 1vh;
        background-color: white;
        padding-left: 1vh;
        color: #0b5793;
    }

    .Tables {
        overflow: hidden;
        overflow-y: auto;
        margin: 1vh;
        height: 71vh;
        grid-area: contentpage;
        display: grid;
        grid-template-areas:
            "Topp"
            "Bott";
        grid-template-rows: 1.25fr .75fr;
    }
    .TablesTwo {
        overflow: hidden;
        overflow-y: auto;
        margin: 1vh;
        height: 71vh;
        grid-area: contentpage;
    }

    .BookTableContents {
        width: 100%;
        font-family: LouisRegular;
        overflow: hidden;
        overflow-y: scroll;
    }

    .BookTableContents td {
        font-size: 2vh;
        border-bottom: 0.1vh solid rgba(0, 0, 0, 0.5);
    }

    .BookTableDetail:hover {
        background-color: rgba(0, 0, 0, 0.02);
    }

    .BookTableContents th {
        background-color: rgba(0, 0, 0, 0.05);
        font-size: 1.75vh;
        font-family: LouisBold;
        font-weight: 900;
    }

    .BookTableContents td,
    th {
        text-align: left;
        padding: 1vh;
    }

    .Topp {
        overflow: hidden;
        overflow-y: auto;
        grid-area: Topp;
    }

    .ListLabel {
        font-family: LouisRegular;
        font-size: 3vh;
        margin: 0;
    }

    .List {
        font-size: 2vh;
        font-family: LouisRegular;
    }

    .Bott {
        grid-area: Bott;
        display: grid;
        grid-template-areas:
            "BottMidd"
            "BottBott";
        grid-template-rows: 1fr 1fr;
    }

    .DateLabel {
        margin: 0;
        font-size: 2vh;
        font-family: LouisRegular;
    }

    .daterange {
        width: 50%;
        text-align: center;
        outline: none;
        height: 20%;
    }

    .BottMidd {
        grid-area: BottMidd;
        display: grid;
        grid-template-areas:
            "Left Right";
        grid-template-columns: 1fr 1fr;
        border-top: 0.1vh solid black;
    }

    .MiddOne {
        grid-area: Left;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .MiddTwo {
        grid-area: Right;
        display: grid;
        grid-template-areas:
            "Lefty Righty";
        grid-template-columns: 1fr 1fr;
    }

    .MiddTwoLeft {
        grid-area: Lefty;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .MiddTwoLeft p {
        font-size: 2.5vh;
        margin: .5vh;
    }

    .MiddTwoRight {
        grid-area: Righty;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .datepickers{
        border:none;
        border-bottom: 0.1vh solid black;
        font-size: 2vh;
        width:200%;
    }

    .form {
        display: flex;
        justify-content: center;
    }

    .MiddTwoRight input {
        outline: none;
        margin: .5vh;
    }

    .AccountInfo {
        margin: 0;
        font-size: 2.5vh;
        color: grey;
        font-family: LouisRegular;
    }

    .BottBott {
        grid-area: BottBott;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .BottTwo {
        display: flex;
        flex-direction: row;
        justify-content: center;
    }

    .Chk {
        margin: 1vh;
        width: 2vh;
        height: 2vh;
    }

    .checky{
        font-size: 2vh;
    }

    .Confirm,
    .Cancel {
        margin: 1vh;
        background: none;
        border: none;
        outline: none;
        color: white;
    }

    .Confirm {
        background-color: #0b5793;
        height: 4vh;
        font-size: 2vh;
        width: 100%;
    }

    .Confirm:hover {
        background-color: #446a88;
        transition: 0.25s ease-in-out;
    }

    .Cancel {
        background-color: #bc2c3c;
        height: 4vh;
        font-size: 2vh;
        width: 49%;
    }

    .Cancel:hover {
        background-color: #bd5d69;
        transition: 0.25s ease-in-out;
    }

    /*Cart*/
    .CartContentPage {
        display: flex;
        height: 90.5vh;
        background-color: rgba(0, 0, 0, 0.05);
    }

    .CartContentPageContents {
        box-shadow: 0vh 0vh 0.5vh rgba(0, 0, 0, 0.5);
        background-color: white;
        height: 82.5vh;
        width: 75%;
        margin: 4vh 1vh 4vh 4vh;
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "contentpage contentpage contentpage";
        grid-template-rows: 9.5vh 73vh;
    }

    .CartContentPageContentsTwo {
        box-shadow: 0vh 0vh 0.5vh rgba(0, 0, 0, 0.5);
        background-color: white;
        height: 82.5vh;
        width: 25%;
        margin: 4vh 4vh 4vh 1vh;
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "contentpage contentpage contentpage";
        grid-template-rows: 9.5vh 73vh;
    }

    .CartHeaders {
        background-color: rgba(0, 0, 0, 0.05);
        align-items: center;
        grid-area: topbar;
        display: flex;
        font-size: 3vh;
        padding-left: 2vh;
        font-family: LouisRegular;
        justify-content: flex-start;
        border-bottom: 0.5vh solid #0b5793;
    }

    .Remarks{
        display:flex;
        color:red;
        justify-content:flex-end;
        width: 80%;
        margin-right:2vh;
    }

    .Remarksgreen{
        display:flex;
        color:green;
        justify-content:flex-end;
        width: 80%;
        margin-right:2vh;
    }

    .Reminders{
        width: fit-content;
        border-bottom: 0.1vh solid black;
        margin: 1vh;
    }
    .Reminders p{
        font-size:2vh;
    }

    .Delete{
        font-size: 1.5vh;
        background-color: #d9534f;
        outline:none;
        border:0.1vh solid black;
        color:white;
        padding:0.5vh;
        border-radius: 0.5vh;
    }

</style>

<body>
    <script>
    function EnabledRemoveButton(checkboxx) {
            var remove = document.getElementById("DeleteEdit");
            var reserve = document.getElementById("Reserve");
            remove.disabled = checkboxx.checked ? false : true;
            reserve.disabled = checkboxx.checked ? false : true;
        }
    
        function Alert(){
            var verify = prompt("Please enter your O365 email to confirm");
            var email = document.getElementById("SidebarAccountEmail").textContent;
            if(verify == email){
                return true;
            }
            else{
                return false;
            }
        }
    </script>
    
    <div class="MaxReso">
        <div class="Container">
            <?php require 'C:\xampp\htdocs\OLMS\Parts\StudentHeader.php'; ?>
            <?php require 'C:\xampp\htdocs\OLMS\Parts\StudentSidebar.php'; ?>
            
            <!--Cart-->
            <div id="CartContentPage" class="CartContentPage">
            
                <div class="CartContentPageContents">
                
                    <div class="CartHeaders">
                        Check out Form
                        <?php
                  if (isset($_GET["Existing"])) {
                    if ($_GET["Existing"] == "Reservation") {
                      echo "<p class='Remarks'>You already have an existing reservation</p>";
                    }
                    else if ($_GET["Existing"] == "Deleted") {
                        echo "<p class='Remarks'>Book removed</p>";
                      }
                      else if ($_GET["Existing"] == "Success") {
                        echo "<p class='Remarksgreen'>Book/s reserved</p>";
                      }
                    
                  }
                ?>
                    </div>
                    <div class="Tables">
                        <div class="Topp">
                            <table class="BookTableContents" cellspacing="0" id="myTable">
                                <tr>
                                    <th>TITLE</th>
                                    <th>AUTHOR</th>
                                    <th>PUBLISHING COMPANY</th>
                                    <th>DATE PUBLISHED</th>
                                    <th></th>
                                </tr>
                                <?php
                                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                if ($conn->connect_error) {
                                    die("Connection failed:" . $conn->connect_error);
                                }
                                $sql = "SELECT * FROM tblreserveticket WHERE AccountId =" . $_GET['Student'];
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                ?>  
                                        
                                        <tr class="BookTableDetail" name="View">
                                            <td><?php echo $row["BookTitle"]; ?></td>
                                            <td><?php echo $row["BookAuthor"]; ?></td>
                                            <td><?php echo $row["BookPublishingCompany"]; ?></td>
                                            <td><?php echo $row["BookPublishingDate"]; ?></td>
                                            <td>
                                                <form action="All.inc.php" method="POST">
                                                <input type="hidden" name="Student" value="<?php echo $_GET['Student']; ?>">
                                                    <input type="hidden" name="View" value="<?php echo $row['BookId']; ?>">
                                                    <input type="submit" id="Delete" formaction="All.inc.php" formmethod="post" onclick="return Alert()" name="Delete" value="Remove" class="Delete">
                                                    
                                                    
                                                </form>
                                            </td>
                                            
                                        </tr>
                                        
                                <?php
                                    }
                                    
                                }
                                ?>
                            </table>
                        </div>
                        <div class="Bott">
                            <div class="BottMidd">
                                <div class="MiddOne">
                                    <?php
                                    $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                                    if ($conn->connect_error) {
                                        die("Connection failed:" . $conn->connect_error);
                                    }
                                    $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Student'];
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        
                                        while ($row = $result->fetch_assoc()) {
                                            echo '<p class="AccountInfo">' . $row["Name"] . '</p>';
                                            echo '<p class="AccountInfo">' . $row["O365"] . '</p>';
                                            echo '<p class="AccountInfo">' . $row["ContactNo"] . '</p>';
                                        }
                                    } else {
                                        echo "0 result";
                                    }
                                    $conn->close();
                                    ?>
                                </div>
                                <form action="All.inc.php" method="post" class="form">
                                    <div class="MiddTwo">
                                        <div class="MiddTwoLeft">
                                            <p class="DateLabel">Select pick up date:</p>
                                            <p class="DateLabel">Select return date:</p>
                                        </div>
                                        <div class="MiddTwoRight">
                                            <input type="date" id="from" name="from" class="datepickers" required/>
                                            <input type="date" id="to" name="to" class="datepickers" required/>
                                            <script>
                                                $("#from").datepicker({
                                                    dateFormat: 'yy-mm-dd',
                                                    changeMonth: true,
                                                    minDate: new Date(),
                                                    maxDate: '+2y',
                                                    onSelect: function(date) {

                                                        var selectedDate = new Date(date);
                                                        var msecsInADay = 86400000;
                                                        var endDateone = new Date(selectedDate.getTime() +
                                                            msecsInADay * 2);
                                                        var endDatetwo = new Date(selectedDate.getTime() +
                                                            msecsInADay * 30);

                                                        //Set Minimum Date of EndDatePicker After Selected Date of StartDatePicker
                                                        $("#to").datepicker("option", "minDate", endDateone);
                                                        $("#to").datepicker("option", "maxDate", endDatetwo);

                                                    }
                                                });

                                                $("#to").datepicker({
                                                    dateFormat: 'yy-mm-dd',
                                                    changeMonth: true,
                                                    minDate: new Date()
                                                });

                                                function EnabledRemoveButton(check) {
                                                    var confirm = document.getElementById("Confirm");
                                                    confirm.disabled = check.checked ? false : true;
                                                }
                                            </script>
                                        </div>
                                    </div>
                            </div>
                            <div class="BottBott">
                                <div class="BottOne">
                                <input type="checkbox" class="Chk" name="check" id="check" onclick="EnabledRemoveButton(this);" required>
                                <label class="checky">Check after reading the reminders.</label>
                                </div>
                                <div class="BottTwo">
                                    
                                        <input type="submit" class="Confirm" name="Confirm" id="Confirm" onclick="return Alert();" value="Confirm" disabled>
                                        <input type="hidden" name="Student" id="Student" value="<?php echo $_GET['Student']; ?>">
                                        
                                    
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="CartContentPageContentsTwo">
                    <div class="CartHeaders">
                        Reminders
                    </div>
                    <div class="TablesTwo">
                    <div class="Reminders">
                    <p>A user could only select a maximum of 30 days prior to selected pick up date</p>
                    </div>
                    <div class="Reminders">
                    <p>Only the books that are on the check out form would be reserved after clicking the confirm button</p>
                    </div>
                    <div class="Reminders">
                    <p>Transactions at the library are only available on weekdays from 8:00 AM to 4:00 PM.</p>
                    </div>
                    <div class="Reminders">
                    <p>A user cannot pick up the reserved book on the day of the selected return date.</p>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>