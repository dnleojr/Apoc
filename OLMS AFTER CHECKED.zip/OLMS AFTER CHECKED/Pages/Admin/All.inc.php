<?php
if (isset($_POST['Checkout'])) {
  $UserId = $_POST['Admin'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $sql = 'SELECT tblaccounts.Id, tblaccounts.Name, tblaccounts.O365, tblaccounts.ContactNo, tblbooks.BookId, tblbooks.BookTitle, tblbooks.BookAuthor, tblbooks.BookDescription, tblbooks.PublishingCompany, tblbooks.PublishingDate FROM tblaccounts INNER JOIN tblbooks ON tblaccounts.Common = tblbooks.Common WHERE BookId=' . $_POST['View'];
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $dup = mysqli_query($conn, "SELECT * FROM tblreserveticket WHERE BookId = $BookId AND AccountId = $UserId");
      if (mysqli_num_rows($dup) > 0) {
        header("location: AdminBooks.php?Admin=$UserId");
      } else {
        $AccountId = $row["Id"];
        $AccountName = $row["Name"];
        $AccountO365 = $row["O365"];
        $AccountNo = $row["ContactNo"];
        $BookId = $row["BookId"];
        $BookTitle = $row["BookTitle"];
        $BookAuthor = $row["BookAuthor"];
        $BookDescription = $row["BookDescription"];
        $BookPublishingDate = $row["PublishingDate"];
        $BookCompany = $row["PublishingCompany"];
        $sqli = "INSERT INTO tblreserveticket (AccountId, AccountName, AccountO365, AccountNo, BookId, BookTitle, BookAuthor, BookDescription, BookPublishingCompany, BookPublishingDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssssssss", $AccountId, $AccountName, $AccountO365, $AccountNo, $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookCompany, $BookPublishingDate);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: AdminBooks.php?Admin=" . $_POST['Admin']);
        exit();
      }
    }
    $conn->close();
    mysqli_close($conn);
  } else {
    echo "0";
  }
  echo "1";
}
if (isset($_POST['Remove'])) {
  $Admin = $_POST['Admin'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
    mysqli_query($conn, 'DELETE FROM tblcart WHERE BookId=' . $id);
  }
  if ($chkarr) {
    echo ("<script>location.replace('AdminCart.php?Admin=$Admin');</script>");
  }
  mysqli_close($conn);
}
if (isset($_POST['Delete'])) {
  $Admin = $_POST['Admin'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  mysqli_query($conn, 'DELETE FROM tblreserveticket WHERE BookId=' . $BookId);
  echo ("<script>location.replace('AdminReserve.php?Admin=$Admin&Existing=Deleted');</script>");
  mysqli_close($conn);
}
if (isset($_POST['DeleteEdit'])) {
  $Admin = $_POST['Admin'];
  $BookId = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
  $sql = 'SELECT * FROM tblbooks WHERE BookId =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $BookId = $row["BookId"];
        $BookTitle = $row["BookTitle"];
        $BookAuthor = $row["BookAuthor"];
        $BookDescription = $row["BookDescription"];
        $BookPublishingDate = $row["PublishingDate"];
        $BookCompany = $row["PublishingCompany"];
        $sqli = "INSERT INTO tbldeleted (BookId, BookTitle, BookAuthor, BookDescription, BookPublishingDate, BookPublishingCompany) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookPublishingDate, $BookCompany);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblbooks WHERE BookId=' . $id);
        header("location: AdminEdit.php?Admin=" . $_POST['Admin']);
      
    }
    
    
  } else {
    echo "0";
  }
 
  }
  if ($chkarr) {
    echo ("<script>location.replace('AdminEdit.php?Admin=$Admin');</script>");
  }
  $conn->close();
  mysqli_close($conn);
}
if (isset($_POST['AddEdit'])) {
  $Admin = $_POST['Admin'];
  header("location: ReserveFormModal.php?Admin=$Admin");
}
if (isset($_POST['Returned'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE AccountId =" . $_POST['AccountId']);
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  $sql = 'SELECT * FROM tblborrowed WHERE AccountId=' . $_POST['AccountId'];
  $result = $conn->query($sql);
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $BookTitle = $row["BookTitle"];
        $BookAuthor = $row["BookAuthor"];
        $BookDescription = $row["BookDescription"];
        $BookPublishingDate = $row["BookPublishingDate"];
        $BookCompany = $row["BookPublishingCompany"];
        $sqli = "INSERT INTO tblbooks(BookTitle, BookAuthor, BookDescription, PublishingDate, PublishingCompany) VALUES (?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "sssss", $BookTitle, $BookAuthor, $BookDescription, $BookPublishingDate, $BookCompany);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        foreach ($ids_array as $array) {
          
          mysqli_query($conn, 'DELETE FROM tblborrowed WHERE BookId=' . $array);
        }
        header("location: AdminReservations.php?Admin=" . $_GET['Admin']);
      }
    }
    exit();
  header("location: AdminReserve.php?Admin=" . $_GET['Admin']);
  $conn->close();
}
if (isset($_POST['Acquired'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE AccountId =" . $_POST['AccountId']);
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  foreach ($ids_array as $array) {
    $S = "1";
    $sqli = "UPDATE tblborrowed SET S = $S WHERE AccountId =" . $_POST['AccountId'];
    $sqlirun = mysqli_query($conn, $sqli);
    header("location: AdminReservations.php?Admin=" . $_GET['Admin']);
  }
  exit();
  $conn->close();
}
if(isset($_POST['SecondCancel'])){
  header("location: AdminReservations.php?Admin=" . $_GET['Admin']);
}
if (isset($_POST['UpdateABook'])) {
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $Title = $_POST["BookTitle"];
  $Author = $_POST["BookAuthor"];
  $Description = $_POST["BookDescription"];
  $Company = $_POST["PublishingCompany"];
  $Date = $_POST["from"];
  $sqli = "UPDATE tblbooks SET BookTitle=?, BookAuthor=?, BookDescription=?, PublishingDate=?, PublishingCompany=? WHERE tblbooks.BookId =" . $_GET['View'];
  $stmt = $conn->prepare($sqli);
  $stmt->bind_param('sssss', $Title, $Author, $Description, $Date, $Company);
  $stmt->execute();
  header("location: AdminEdit.php?Admin=" . $_GET['Admin']);
}
if (isset($_POST["Confirm"])) {
  $Admin = $_POST["Admin"];
  $from = $_POST["from"];
  $to = $_POST["to"];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $ids_array = array();
  $resultbook = mysqli_query($conn, "SELECT * FROM tblreserveticket WHERE AccountId = $Admin;");
  while ($rowbook = mysqli_fetch_array($resultbook)) {
    $ids_array[] = $rowbook['BookId'];
  }
  foreach ($ids_array as $array) {
    $dup = mysqli_query($conn, "SELECT * FROM tblborrowed WHERE BookId = $array OR AccountId = $Admin");
    if (mysqli_num_rows($dup) > 0) {
      header("location:AdminReserve.php?Admin=$Admin&Existing=Reservation");
    } else {
      $sql = 'SELECT * FROM tblreserveticket WHERE AccountId=' . $Admin;
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
          $AccountId = $row["AccountId"];
          $AccountName = $row["AccountName"];
          $AccountO365 = $row["AccountO365"];
          $AccountNo = $row["AccountNo"];
          $BookId = $row["BookId"];
          $BookTitle = $row["BookTitle"];
          $BookAuthor = $row["BookAuthor"];
          $BookDescription = $row["BookDescription"];
          $BookPublishingDate = $row["BookPublishingDate"];
          $BookCompany = $row["BookPublishingCompany"];
          $sqli = "INSERT INTO tblborrowed (AccountId, AccountName, AccountO365, AccountNo, BookId, BookTitle, BookAuthor, BookDescription, BookPublishingCompany, BookPublishingDate, PickupDate, ReturnDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
          $stmt = mysqli_stmt_init($conn);
          if (!mysqli_stmt_prepare($stmt, $sqli)) {
            header("location: Register.php?error=stmtfailed");
            exit();
          }
          mysqli_stmt_bind_param($stmt, "ssssssssssss", $AccountId, $AccountName, $AccountO365, $AccountNo, $BookId, $BookTitle, $BookAuthor, $BookDescription, $BookCompany, $BookPublishingDate, $from, $to);
          mysqli_stmt_execute($stmt);
          mysqli_stmt_close($stmt);
          foreach ($ids_array as $array) {
            mysqli_query($conn, 'DELETE FROM tblreserveticket WHERE BookId=' . $array);
            mysqli_query($conn, 'DELETE FROM tblbooks WHERE BookId=' . $array);
          }
          header("location: AdminReserve.php?Admin=$Admin&Existing=Success");
        }
      }
    }
    exit();
  }
  header("location: AdminReserve.php?Admin=$Admin");
  $conn->close();
}
if(isset($_POST['Register'])){
  $Admin = $_POST['Admin'];
  header("location: Register.php?Admin=$Admin");
}
if(isset($_POST['DeleteStudent'])){
  $Admin = $_POST['Admin'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $chkarr = $_POST['checkboxx'];
  foreach ($chkarr as $id) {
    
  $sql = 'SELECT * FROM tblaccounts WHERE Id =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $AccountId = $row["Id"];
        $AccountO365 = $row["O365"];
        $AccountName = $row["Name"];
        $AccountPassword = $row["Password"];
        $AccountContactNo = $row["ContactNo"];
        $AccountRole = $row["Role"];
        $sqli = "INSERT INTO tbldeleted (AccountId, AccountO365, AccountName, AccountPassword, AccountContactNo, AccountRole) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $AccountId, $AccountO365, $AccountName, $AccountPassword, $AccountContactNo, $AccountRole);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblaccounts WHERE Id=' . $id);
        header("location: AdminProfiles.php?Admin=" . $_POST['Admin']);
        
      
    }
    
  } else {
    echo "0";
  }
  }
  if ($chkarr) {
    echo ("<script>location.replace('AdminProfiles.php?Admin=$Admin');</script>");
  }
  $conn->close();
  mysqli_close($conn);
}
if(isset($_POST['DeleteLibrarian'])){
  $Admin = $_POST['Admin'];
  $id = $_POST['View'];
  $serverName = 'localhost';
  $dbUsername = 'root';
  $dbPassword = '';
  $dbName = 'accountsystem';
  $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);
  if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
  }
  $sql = 'SELECT * FROM tblaccounts WHERE Id =' .$id;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $AccountId = $row["Id"];
        $AccountO365 = $row["O365"];
        $AccountName = $row["Name"];
        $AccountPassword = $row["Password"];
        $AccountContactNo = $row["ContactNo"];
        $AccountRole = $row["Role"];
        $sqli = "INSERT INTO tbldeleted (AccountId, AccountO365, AccountName, AccountPassword, AccountContactNo, AccountRole) VALUES (?, ?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sqli)) {
          header("location: Register.php?error=stmtfailed");
          exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $AccountId, $AccountO365, $AccountName, $AccountPassword, $AccountContactNo, $AccountRole);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_query($conn, 'DELETE FROM tblaccounts WHERE Id=' . $id);
        header("location: AdminProfiles.php?Admin=" . $_POST['Admin']);
        exit();
      
    }
    
    $conn->close();
    mysqli_close($conn);
  } else {
    echo "0";
  }
    echo ("<script>location.replace('AdminProfiles.php?Admin=$Admin');</script>");
  mysqli_close($conn);
}