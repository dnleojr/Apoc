<?php
function PasswordConfirmed($Password, $ConfirmPassword)
{
    $result;
    if ($Password !== $ConfirmPassword) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}

function FullNameExists($conn, $FullName)
{
    $sql = "SELECT * FROM tblaccounts WHERE Name = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: Register.php?error=stmtfailed");
        exit();
    }
    mysqli_stmt_bind_param($stmt, "s", $FullName);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($resultData)) {
        return $row;
    } else {
        $result = false;
        return $result;
    }
    mysqli_stmt_close($stmt);
}
function EmailExists($conn, $Email)
{
    $sql = "SELECT * FROM tblaccounts WHERE O365 = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: Register.php?error=stmtfailed");
        exit();
    }
    mysqli_stmt_bind_param($stmt, "s", $Email);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($resultData)) {
        return $row;
    } else {
        $result = false;
        return $result;
    }
    mysqli_stmt_close($stmt);
}
function createUser($conn, $Email, $FullName, $Password, $ContactNumber, $Role)
{
    $sql = "INSERT INTO tblaccounts (O365, Name, Password, ContactNo, Role) VALUES (?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: Register.php?error=stmtfailed");
        exit();
    }
    $HashedPassword = password_hash($Password, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmt, "sssss", $Email, $FullName, $HashedPassword, $ContactNumber, $Role);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: AdminProfiles.php?Admin=" .$_POST['Admin']);
    exit();
}
function loginUser($conn, $Email, $Password)
{
    $EmailExists = EmailExists($conn, $Email);
    if ($EmailExists === false) {
        header("location: index.php?error=wronglogin");
        exit();
    }

    $PasswordHashed = $EmailExists["Password"];
    $CheckPassword = password_verify($Password, $PasswordHashed);
    if ($CheckPassword === false) {
        header("location: index.php?error=wronglogin");
        exit();
    } else if ($CheckPassword === true) {
        $Role = $EmailExists["Role"];
        if ($Role == "1") {
            session_start();
            $_SESSION["Admin"] = $EmailExists["Id"];
            header("location: AdminBooks.php?Admin=" . $EmailExists["Id"]);
            exit();
        } else if ($Role == "2") {
            session_start();
            $_SESSION["Librarian"] = $EmailExists["Id"];
            header("location: ../Librarian/LibrarianBooks.php?Librarian=" . $EmailExists["Id"]);
            exit();
        } else if ($Role == "3") {
            session_start();
            $_SESSION["Student"] = $EmailExists["Id"];
            header("location: ../Student/StudentBooks.php?Student=" . $EmailExists["Id"]);
            exit();
        }
    }
}