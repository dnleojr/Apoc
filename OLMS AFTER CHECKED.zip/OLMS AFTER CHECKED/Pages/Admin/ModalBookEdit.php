<?php
session_start();
if (!isset($_SESSION["Admin"])) {
    header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/themes/base/jquery-ui.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
</head>
<style>
    @font-face {
        font-family: 'LouisBold';
        src: url('../Fonts/louis_george_cafe_bold-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe_bold-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: 'LouisRegular';
        src: url('../Fonts/louis_george_cafe-webfont.woff2') format('woff2'),
            url('../Fonts/louis_george_cafe-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }

    body {
        margin: 0;
    }

    .Container {
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "sidebar contentpage contentpage";
        grid-template-columns: 0.5fr 3.5fr;
        grid-template-rows: 9.5vh 90.5vh;
    }

    .Header {
        grid-area: topbar;
        background-color: #0b5793;
        display: flex;
        align-items: center;
    }

    .Header p {
        color: white;
        margin: 0px 0px 0px 5vh;
        font-size: 4vh;
        font-family: LouisBold;
    }

    .Sidebar {
        grid-area: sidebar;
        background-color: white;
        border-right: 1vh solid #f4d03f;
    }

    .SidebarContents {
        margin: 5vh 5vh 5vh 5vh;
        display: grid;
        height: 80.5vh;
        grid-template-areas:
            "AccountHead"
            "Selects"
            "Options";
        grid-template-rows: 1fr 2fr 1fr;
        grid-template-columns: 1fr;
    }

    .Account {
        grid-area: AccountHead;
        align-self: flex-start;
    }

    .SidebarAccountName {
        color: black;
        font-family: LouisRegular;
        font-size: 3.5vh;
        margin: 0;
        overflow: hidden;
        width: 6.5em;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .SidebarAccountEmail,
    .SidebarAccountContactNo {
        color: #000000;
        opacity: 50%;
        font-family: LouisRegular;
        font-size: 1.75vh;
        margin: 0;
        width: 13em;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .HROne {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 2vh 0vh 0vh 0vh;
    }

    .Buttons {
        height: 100%;
        grid-area: Selects;
    }

    .ButtonContainer {
        height: 100%;
        width: 100%;
    }

    .Button {
        display: flex;
        align-items: center;
        width: 100%;
        height: 7vh;
        font-size: 2.5vh;
        background: none;
        font-family: LouisRegular;
        outline: none;
        border: none;
    }

    .Button:hover {
        background: rgba(0, 0, 0, 0.05);
    }

    .HRTwo {
        width: 100%;
        height: 0.10vh;
        opacity: 50%;
        background-color: black;
        margin: 0vh 0vh 2vh 0vh;
    }

    .Options {
        align-self: flex-end;
        grid-area: Options;
    }

    .Option {
        display: block;
        text-decoration: none;
        color: #0b5793;
        font-family: LouisRegular;
        font-size: 2vh;
        margin: 0;
    }

    .Headers {
        background-color: rgba(0, 0, 0, 0.05);
        align-items: center;
        grid-area: topbar;
        display: grid;
        border-bottom: 0.5vh solid #0b5793;
    }

    .Searcher {
        grid-area: topbar;
        display: block;
        outline: none;
        font-family: LouisRegular;
        font-size: 3vh;
        border: 0.1vh solid #0b5793;
        width: 25vh;
        margin: 0vh 0vh 0vh 1vh;
        background-color: white;
        padding-left: 1vh;
        color: #0b5793;
    }

    .Tables {
        overflow: hidden;
        overflow-y: auto;
        margin: 1vh;
        height: 71vh;
        grid-area: contentpage;
    }



    .DateLabel {
        margin: 0;
        font-size: 2vh;
        font-family: LouisRegular;
    }

    .daterange {
        width: 50%;
        text-align: center;
        outline: none;
        height: 20%;
    }

    .BottMidd {
        grid-area: BottMidd;
        display: grid;
        grid-template-areas:
            "Left Right";
        grid-template-columns: 1fr 1fr;
        border-top: 0.1vh solid black;
    }

    .MiddOne {
        grid-area: Left;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .MiddTwo {
        grid-area: Right;
        display: grid;
        grid-template-areas:
            "Lefty Righty";
        grid-template-columns: 1fr 1fr;
    }

    .MiddTwoLeft {
        grid-area: Lefty;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .MiddTwoLeft p {
        font-size: 2.5vh;
        margin: .5vh;
    }

    .MiddTwoRight {
        grid-area: Righty;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .datepickers {
        border: none;
        border-bottom: 0.1vh solid black;
        outline: none;
        font-size: 2.5vh;
        margin-bottom: 2vh;
        width:200%
    }

    .form {
        display: flex;
        justify-content: center;
    }

    .MiddTwoRight input {
        outline: none;
        margin: .5vh;
    }

    .AccountInfo {
        margin: 0;
        font-size: 2.5vh;
        color: grey;
        font-family: LouisRegular;
    }

    .BottBott {
        grid-area: BottBott;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .BottTwo {
        display: flex;
        flex-direction: row;
        justify-content: center;
    }

    .Chk {
        margin: 1vh;
        width: 2vh;
        height: 2vh;
    }

    .checky {
        font-size: 2vh;
    }

    .Confirm,
    .Cancel {
        background: none;
        border: none;
        outline: none;
        color: white;
    }

    .Confirm {
        background-color: #0b5793;
        height: 4vh;
        font-size: 2vh;
        width: 100%;
    }

    .Confirm:hover {
        background-color: #446a88;
        transition: 0.25s ease-in-out;
    }

    .Cancel {
        background-color: #bc2c3c;
        height: 4vh;
        font-size: 2vh;
        width: 49%;
    }

    .Cancel:hover {
        background-color: #bd5d69;
        transition: 0.25s ease-in-out;
    }

    /*Cart*/
    .CartContentPage {
        display: flex;
        justify-content: center;
        height: 90.5vh;
        background-color: rgba(0, 0, 0, 0.05);
    }

    .CartContentPageContents {
        box-shadow: 0vh 0vh 0.5vh rgba(0, 0, 0, 0.5);
        background-color: white;
        height: 82.5vh;
        width: 50%;
        margin: 4vh 4vh 4vh 4vh;
        display: grid;
        grid-template-areas:
            "topbar topbar topbar"
            "contentpage contentpage contentpage";
        grid-template-rows: 9.5vh 73vh;
    }

    .CartHeaders {
        background-color: rgba(0, 0, 0, 0.05);
        align-items: center;
        grid-area: topbar;
        display: flex;
        font-size: 3vh;
        padding-left: 2vh;
        font-family: LouisRegular;
        justify-content: flex-start;
        border-bottom: 0.5vh solid #0b5793;
    }

    .AddABookForm {
        margin: 3vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        overflow-x: hidden;
        overflow-y: auto;
    }

    .Label {
        font-family: LouisRegular;
        font-size: 2.5vh;
    }

    .Input {
        margin: 0vh 0vh 2vh 0vh;
        height: 4vh;
        outline: none;
        border: none;
        border-bottom: 0.1vh solid black;
    }

    .InputDesc {
        margin: 0vh 0vh 2vh 0vh;
        height: 20vh;
        width: 98.5%;
        resize: none;
        outline: none;
        border: 0.1vh solid black;
    }
</style>

<body>
    <script>
     function EnabledRemoveButton(checkboxx) {
            var confirm = document.getElementById("UpdateABook");
            confirm.disabled = checkboxx.checked ? false : true;
        }
        function Alert(){
            var verify = prompt("Please enter your O365 email to confirm");
            var email = document.getElementById("SidebarAccountEmail").textContent;
            if(verify == email){
                return true;
            }
            else{
                return false;
            }
        }
    </script>
    <div class="MaxReso">
        <div class="Container">
            <?php require 'C:\xampp\htdocs\OLMS\Parts\Header.php'; ?>
            <?php require 'C:\xampp\htdocs\OLMS\Parts\Sidebar.php'; ?>
            <!--Cart-->
            <div id="CartContentPage" class="CartContentPage">
                <div class="CartContentPageContents">
                    <div class="CartHeaders">
                        Edit book information
                    </div>
                    <div class="Tables">
                        <?php
                        $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                        if ($conn->connect_error) {
                            die("Connection failed:" . $conn->connect_error);
                        }
                        $sql = "SELECT * FROM tblbooks WHERE BookId= ".$_GET['View'];
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                        ?>
                                <form class="AddABookForm">
                                    <label class="Label">Book Title:</label>
                                    <input type="text" name="BookTitle" id="BookTitle" class="Input" value="<?php echo $row['BookTitle'];?>" required>
                                    <label class="Label">Book Author:</label>
                                    <input type="text" name="BookAuthor" id="BookAuthor" class="Input" value="<?php echo $row['BookAuthor'];?>" required>
                                    <label class="Label">Publishing Company:</label>
                                    <input type="text" name="PublishingCompany" id="PublishingCompany" class="Input" value="<?php echo $row['PublishingCompany'];?>" required>
                                    <label class="Label">Date Published:</label>
                                    <input type="date" id="from" name="from" class="datepickers" value="<?php echo $row['PublishingDate'];?>" required>
                                    <label class="Label">ISBN-10:</label>
                            <input type="number" pattern="^(\d{10})$" name="Ten" class="datepickers" value="<?php echo $row['ISBNTEN'];?>" required>
                            <label class="Label">ISBN-13:</label>
                            <input type="text" pattern="^(\d{3})+-+(\d{10})$" name="Thirteen" class="datepickers" value="<?php echo $row['ISBNTHIRTEEN'];?>" required>
                                    <script>
                                        $("#from").datepicker({
                                            dateFormat: 'yy-mm-dd',
                                            changeMonth: true,
                                            changeYear: true,
                                            yearRange: "-100:+0",
                                            maxDate: new Date()
                                        });
                                    </script>
                                    <label class="Label">Book Description:</label>
                                    <textarea name="BookDescription" id="BookDescription" class="InputDesc" required><?php echo $row['BookDescription'];?></textarea>
                                    <label class="checky">
                            <input type="checkbox" id="checkboxx" class="Chk" name="checkboxx[]" onclick="EnabledRemoveButton(this);" required>
                            Check to confirm action</label>
                                    <input type="submit" name="UpdateABook" id="UpdateABook" formaction="All.inc.php?Admin=<?php echo $_GET['Admin']; ?>&View=<?php echo $row['BookId']; ?>" formmethod="post" onclick="return Alert();" class="Confirm" disabled>
                                    <input type="hidden" name="Admin" value="<?php echo $_GET['Admin']; ?>">
                                </form>
                        <?php

                            }
                        }

                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>