<?php
$BookTitle = $_POST['BookTitle'];
$BookAuthor = $_POST['BookAuthor'];
$BookDescription = $_POST['BookDescription'];
$PublishingCompany = $_POST['PublishingCompany'];
$DatePublished = $_POST['from'];
$Ten = $_POST['Ten'];
$Thirteen = $_POST['Thirteen'];
$conn = mysqli_connect("localhost", "root", "", "accountsystem");
if ($conn->connect_error) {
  die("Connection failed:" . $conn->connect_error);
}
if (isset($_POST['AddABook'])) {

  $sqli = "INSERT INTO tblbooks (BookTitle, BookAuthor, BookDescription, PublishingDate, PublishingCompany, ISBNTEN, ISBNTHIRTEEN) VALUES (?, ?, ?, ?, ?, ?, ?);";
  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt, $sqli)) {
    header("location: Register.php?error=stmtfailed");
    exit();
  }
  mysqli_stmt_bind_param($stmt, "sssssss", $BookTitle, $BookAuthor, $BookDescription, $DatePublished, $PublishingCompany, $Ten, $Thirteen);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_close($stmt);
  header("location: AdminEdit.php?Admin=" .$_POST['Admin']);
  exit();
}
