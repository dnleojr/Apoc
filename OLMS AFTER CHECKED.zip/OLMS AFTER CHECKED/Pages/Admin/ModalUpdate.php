<?php
session_start();
if (!isset($_SESSION["Admin"])) {
  header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php
          $conn = mysqli_connect("localhost", "root", "", "accountsystem");
          if ($conn->connect_error) {
            die("Connection failed:" . $conn->connect_error);
          }
          $sql = 'SELECT * from tblbooks WHERE BookId =' . $_GET['View'];
          $result = $conn->query($sql);
          if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
              echo $row["BookTitle"];
            }
          } else {
            echo "0 result";
          }
          $conn->close();
          ?>
  </title>
  <style>
    @font-face {
      font-family: 'LouisBold';
      src: url('../Fonts/louis_george_cafe_bold-webfont.woff2') format('woff2'),
        url('../Fonts/louis_george_cafe_bold-webfont.woff') format('woff');
      font-weight: normal;
      font-style: normal;
    }

    @font-face {
      font-family: 'LouisRegular';
      src: url('../Fonts/louis_george_cafe-webfont.woff2') format('woff2'),
        url('../Fonts/louis_george_cafe-webfont.woff') format('woff');
      font-weight: normal;
      font-style: normal;
    }

    body {
      margin: 0;
      padding: 0;
    }

    .Modalbg {
      background-image: url(Modalbg.png);
      background-repeat: no-repeat;
      object-fit: cover;
      background-size: cover;
    }

    .Modal {
      display: block;
      /* Hidden by default */
      position: fixed;
      /* Stay in place */
      width: 100%;
      /* Full width */
      height: 100%;
      /* Full height */
      overflow: auto;
      /* Enable scroll if needed */
    }

    .ModalMainContainer {
      margin: 0 auto;
      height: 100vh;
      width: 75%;
      vertical-align: middle;
    }

    .ModalSecondaryContainer {
      background-color: white;
      height: 75vh;
      border: 1vh solid #f4d03f;
    }

    .ModalInnerGridContainer {
      display: grid;
      grid-template-areas:
        "BookMain VRHR BookDesc";
      grid-template-columns: 1fr 0.001fr 1fr;
      grid-template-rows: 75vh;
    }

    .BookMain {
      grid-area: BookMain;
      margin: 2.5vh 2.5vh 2.5vh 2.5vh;
      display: grid;
      grid-template-areas:
        "BookMainOne"
        "BookMainTwo";
      grid-template-rows: 60vh 10vh;
    }

    .BookMainOne {
      grid-area: BookMainOne;
      position: relative;
      display: flex;
      flex-direction: column;
    }

    .form {
      display: flex;
      flex-direction: column;
    }

    .Title,
    .Author,
    .PublishingCompany,
    .DatePublished {
      margin: 0vh 0vh 1vh 0vh;
    }

    .Title{
    font-size: 3.5vh;
    font-family: LouisBold;
}

.Author{
    font-size: 2vh;
    font-family: LouisBold;
}

.PublishingCompany{
    font-size: 2vh;
    font-family: LouisRegular;
}

.DatePublished{
    font-size: 2vh;
    font-family: LouisRegular;
}

    .SaveItem {
      background-color: #5cb85c;
      color: white;
      border: none;
      outline: none;
      font-family: LouisRegular;
      font-size: 2vh;
      height: 5vh;
      width: 20vh;
      margin: 1vh 0vh 0vh 0vh;
    }

    .Checkout {
      background-color: #0b5793;
      color: white;
      border: none;
      outline: none;
      font-family: LouisRegular;
      font-size: 2vh;
      height: 5vh;
      width: 20vh;
      margin: 1vh 0vh 0vh 0vh;
    }

    .Close {
      background-color: #bc2c3c;
      color: white;
      border: none;
      outline: none;
      font-family: LouisRegular;
      font-size: 2vh;
      height: 5vh;
      width: 20vh;
      margin: 1vh 0vh 0vh 0vh;
    }

    .Checkout:hover {
      opacity: 75%;
      transition: 0.25s ease-in-out;
    }

    .Close:hover {
      background-color: #bd5d69;
      transition: 0.25s ease-in-out;
    }

    .SaveItem:hover {
      opacity: 75%;
      transition: 0.25s ease-in-out;
    }

    .BookMainTwo {
      grid-area: BookMainTwo;
      position: relative;
      display: flex;
      flex-direction: column;
    }

    .AccountContainer {
      position: absolute;
      bottom: 0;
    }

    .Account {
      opacity: 50%;
      font-family: LouisRegular;
      font-size: 2.5vh;
      margin: 0;
    }

    .VRHR {
      grid-area: VRHR;
      background-color: black;
      margin: 2.5vh 0vh 2.5vh 0vh;
    }

    .BookDesc {
      grid-area: BookDesc;
      margin: 2.5vh 2.5vh 2.5vh 2.5vh;
      overflow: auto;
      overflow-x: hidden;
    }

    .BookDesc p {
      margin: 0;
      font-size: 2vh;
      font-family: LouisRegular;
    }
  </style>
  <script>
    function AlertCheckout() {
      alert("Book added to check out form");
    }
  </script>
</head>

<body class="Modalbg">
  <div id="myModal" class="Modal">
    <table class="ModalMainContainer">
      <tr>
        <td>
          <div class="ModalSecondaryContainer">
            <div class="ModalInnerGridContainer">
              <div class="BookMain">
                <div class="BookMainOne">
                  <?php
                  $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                  if ($conn->connect_error) {
                    die("Connection failed:" . $conn->connect_error);
                  }
                  $sql = 'SELECT * from tblbooks WHERE BookId =' . $_GET['View'];
                  $result = $conn->query($sql);
                  if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                      echo '<p class="Title">' . $row["BookTitle"] . '</p>';
                      echo '<p class="Author">Author: ' . $row["BookAuthor"] . '</p>';
                      echo '<p class="PublishingCompany">Publisher: ' . $row["PublishingCompany"] . '</p>';
                      echo '<p class="DatePublished">Date Published: ' . $row["PublishingDate"] . '</p>';
                      echo '<p class="DatePublished">ISBN-10: ' . $row["ISBNTEN"] . '</p>';
                      echo '<p class="DatePublished">ISBN-13: ' . $row["ISBNTHIRTEEN"] . '</p>';
                    }
                  } else {
                    echo "0 result";
                  }
                  $conn->close();
                  ?>

                  <form action="ModalBookEdit.php?Admin=<?php echo $_GET['Admin']; ?>&View=<?php echo $_GET['View']; ?>" method="post" class="form">
                    <button class="Checkout" value="Edit" id="Edit" name="Edit">Edit</button>
                  </form>
                  <button class="Close" onclick="location.replace('AdminEdit.php?Admin=<?php echo $_GET['Admin'];?>');">Close</button>

                </div>
                <div class="BookMainTwo">

                  <div class="AccountContainer">
                    <?php
                    $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                    if ($conn->connect_error) {
                      die("Connection failed:" . $conn->connect_error);
                    }
                    $sql = 'SELECT * from tblaccounts WHERE Id =' . $_GET['Admin'];
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                        echo '<p class="Account">' . $row["Name"] . '</p>';
                        echo '<p class="Account">' . $row["O365"] . '</p>';
                        echo '<p class="Account">' . $row["ContactNo"] . '</p>';
                      }
                    } else {
                      echo "0 result";
                    }
                    $conn->close();
                    ?>
                  </div>
                </div>
              </div>
              <div class="VRHR"></div>
              <div class="BookDesc">
                <?php
                $conn = mysqli_connect("localhost", "root", "", "accountsystem");
                if ($conn->connect_error) {
                  die("Connection failed:" . $conn->connect_error);
                }
                $sql = 'SELECT * from tblbooks WHERE BookId =' . $_GET['View'];
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                  while ($row = $result->fetch_assoc()) {
                    echo '<p class="Title">' . nl2br($row["BookDescription"]) . '</p>';
                  }
                } else {
                  echo "0 result";
                }
                $conn->close();
                ?>
              </div>
            </div>
          </div>
        </td>
      </tr>
    </table>
  </div>
</body>

</html>