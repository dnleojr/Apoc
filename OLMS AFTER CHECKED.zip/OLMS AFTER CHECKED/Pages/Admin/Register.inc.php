<?php
if(isset($_POST["Continue"])) {
    $Email = $_POST["Email"];
    $FullName = $_POST["FullName"];
    $Password = $_POST["Password"];
    $ConfirmPassword = $_POST["ConfirmPassword"];
    $ContactNumber = $_POST["ContactNumber"];
    $Role = $_POST["Role"];
    $Admin = $_POST['Admin'];

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';

    if (PasswordConfirmed($Password, $ConfirmPassword) !== false) {
        header("location: Register.php?error=passwordsdontmatch&Admin=$Admin");
        exit();
    }
    if (FullNameExists($conn, $FullName) !== false) {
        header("location: Register.php?error=namealreadyexists&Admin=$Admin");
        exit();
    }
    if (EmailExists($conn, $Email) !== false) {
        header("location: Register.php?error=emailalreadyexists&Admin=$Admin");
        exit();
    }

    createUser($conn, $Email, $FullName, $Password, $ContactNumber, $Role);
}
else {
    header("location: Register.php");
}
