<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Login</title>
</head>
<style>
@font-face {
    font-family: 'LouisBold';
    src: url('../Fonts/louis_george_cafe_bold-webfont.woff2') format('woff2'),
        url('../Fonts/louis_george_cafe_bold-webfont.woff') format('woff');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'LouisRegular';
    src: url('../Fonts/louis_george_cafe-webfont.woff2') format('woff2'),
        url('../Fonts/louis_george_cafe-webfont.woff') format('woff');
    font-weight: normal;
    font-style: normal;
}


body{
    margin: 0;
}

.Container{
    display: grid;
    grid-template-areas: 
        "topbar topbar topbar"
        "sidebar contentpage contentpage";
    grid-template-columns: 1fr 3fr;
    grid-template-rows: 9.5vh 90.5vh;
}

.Header{
    grid-area: topbar;
    background-color: #0b5793;
    border-top: 1vh solid #f4d03f;
    display: flex;
    align-items: center;
}

.Header p{
    color: white;
    margin: 0px 0px 0px 5vh;
    font-size: 4vh;
    font-family: LouisBold;
}

.Sidebar{
    grid-area: sidebar;
    background-color: white;
    display: flex;
    align-items: center;
}

.SidebarContents{
    margin: 5vh 5vh 5vh 5vh;
    width: 100%;
}

.SidebarHeader{
    margin: 0;
    color: #0b5793;
    font-size: 5vh;
    font-family: LouisBold;
}

.Inputs{
    margin: 5vh 0px 0px 0px ;
}

.FormLabelOne, .FormLabelTwo, .FormLabelThree, .FormLabelFour{
    font-family: LouisRegular;
    font-size: 2vh;
}

.SecondaryLabel{
    font-family: LouisRegular;
    font-size: 2vh;
    color: #8a8a8a;
}

.Input{
    border: none;
    outline: none;
    border-bottom: 1px solid #b5b5b5;
    width: 100%;
    font-size: 2vh;
    margin: 1vh 0px 1vh 0px;
}

.FormButton{
    background-color: #0b5793;
    border: none;
    color: white;
    font-family: LouisRegular;
    padding: 1.5vh;
    border-radius: 100px;
    width: 100%;
    outline: none;
    margin: 2vh 0px 2vh 0px;
    font-size: 1.5vh;
}

.FormButton:hover{
    background-color: #446a88;
    transition: 0.25s ease-in-out;
}

.OptionsContainer{
    margin: 1vh 0vh 0vh 0vh;
}

.Options{
    color: #0b5793;
    font-family: Louisregular;
    font-size: 2vh;
    line-height: 2vh;
    text-decoration: none;
}

.ContentPage{
    grid-area: contentpage;
    background-color: rosybrown;
    background-image: url(OpeningImage.jpg);
    background-size: cover;
    background-repeat: no-repeat;
}

.MaxReso{
}

</style>
<body>
    <div class="MaxReso">
    <div class="Container">
        <?php
            include_once 'C:\xampp\htdocs\OLMS\Parts\Header.php';
        ?>

        <div class="Sidebar">
            <div class="SidebarContents">
                <p class="SidebarHeader">Login</p>
                <form class="Inputs" action="Login.inc.php" method="post">
                <label class="FormLabelOne">O365 Email</label><br>
                <input type="email" class="Input" name="Email" required><br>



                <label class="FormLabelThree">Password</label><br>
                <input type="password" class="Input" name="Password" required><br>


                <button class="FormButton" type="submit" name="Continue">CONTINUE</button>
                <?php
                  if (isset($_GET["error"])) {
                    if ($_GET["error"] == "wronglogin") {
                      echo "<p>Incorrect login details</p>";
                    }
                  }
                ?>
                </form>
                <div class="OptionsContainer">
            </div>
            </div>
        </div>

        <div class="ContentPage">

        </div>
    </div>
</div>
</body>
</html>
