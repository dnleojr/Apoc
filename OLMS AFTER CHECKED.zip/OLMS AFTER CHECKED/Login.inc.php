<?php
if (isset($_POST["Continue"])) {
  $Email = $_POST["Email"];
  $Password = $_POST["Password"];


  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';

  loginUser($conn, $Email, $Password);
}
else{
  header ("location: index.php");
  exit();
}
