-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2021 at 08:42 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accountsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaccounts`
--

CREATE TABLE `tblaccounts` (
  `Id` int(11) NOT NULL,
  `O365` varchar(50) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `ContactNo` varchar(50) DEFAULT NULL,
  `Role` int(1) DEFAULT NULL,
  `Common` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblaccounts`
--

INSERT INTO `tblaccounts` (`Id`, `O365`, `Name`, `Password`, `ContactNo`, `Role`, `Common`) VALUES
(11, 'admin.123456@sjdelmonte.sti.edu.ph', 'Admin Acccount', '$2y$10$t8OjgQROirPuOcKKbvCChepDnx/Qg9aUMa4DOXSBttJ7YMbebljoW', '09437440050', 1, 1),
(43, 'dauigoy.123456@sjdelmonte.sti.edu.ph', 'Clyde Kristofer Dauigoy', '$2y$10$mpWXj6kbu5RA7o3zAp5i4.k7Z0Z95YV8Z91G2rjDQvbEFtDN7v4l.', '09876543219', 3, 1),
(44, 'tejima.199097@sjdelmonte.sti.edu.ph', 'Yhuan Shin Tejima', '$2y$10$AW8MuI9lQ0azOkjq2K4eSeQnAYLd2AlaFbuBIjK1lE8yMqDnXl6pW', '09101112131', 3, 1),
(48, 'sindao.123456@sjdelmonte.sti.edu.ph', 'Louis Matthew Sindao', '$2y$10$Ekf3K/u7Qg9RARilNA0Qse8IBu4dL0a5OLmd5MvJrGi69E/7IE2j2', '09123456789', 2, 1),
(56, 'student.123456@sjdelmonte.sti.edu.ph', 'Student Account', '$2y$10$i0h7s2/vZlw23t1ArJLVfejnuiu8PMHoc.qWFbaK2F2RGhYH/mMBe', '09876543211', 3, 1),
(57, 'librarian.123456@sjdelmonte.sti.edu.ph', 'Librarian Account', '$2y$10$g9iese6Xbo1dS9x5zfC0/.F5vtSm7gD2iUaAXFJpiVFAXL/AaHtza', '09437440050', 2, 1),
(58, 'yabot.123456@sjdelmonte.sti.edu.ph', 'Dan Leo L. Yabot Jr.', '$2y$10$uritCpTIjsjVjoSm1pPM4.8aS1MhZk/aBZhs7JhS.S88fa4WKuRya', '09437440050', 2, 1),
(59, 'arpon.123456@sjdelmonte.sti.edu.ph', 'Aldrin Arpon', '$2y$10$/g35qvic/Jgms0xjN3sp7euMrOS/cbbeFJAa0OpCEBJtCAiNBWt2y', '09437440050', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblbooks`
--

CREATE TABLE `tblbooks` (
  `BookId` int(11) NOT NULL,
  `BookTitle` longtext DEFAULT NULL,
  `BookAuthor` varchar(50) DEFAULT NULL,
  `BookDescription` longtext DEFAULT NULL,
  `PublishingDate` date DEFAULT NULL,
  `PublishingCompany` varchar(100) DEFAULT NULL,
  `Common` int(11) NOT NULL DEFAULT 1,
  `ISBNTEN` longtext DEFAULT NULL,
  `ISBNTHIRTEEN` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblbooks`
--

INSERT INTO `tblbooks` (`BookId`, `BookTitle`, `BookAuthor`, `BookDescription`, `PublishingDate`, `PublishingCompany`, `Common`, `ISBNTEN`, `ISBNTHIRTEEN`) VALUES
(129, 'Elements of Programming Interviews in Python: The Insiders\' Guide', 'Adnan Aziz', 'EPI is your comprehensive guide to interviewing for software development roles.\r\n\r\nThe core of EPI is a collection of over 250 problems with detailed solutions. The problems are representative of interview questions asked at leading software companies. The problems are illustrated with 200 figures, 300 tested programs, and 150 additional variants.\r\n\r\nThe book begins with a summary of the nontechnical aspects of interviewing, such as strategies for a great interview, common mistakes, perspectives from the other side of the table, tips on negotiating the best offer, and a guide to the best ways to use EPI. We also provide a summary of data structures, algorithms, and problem solving patterns.\r\n\r\nCoding problems are presented through a series of chapters on basic and advanced data structures, searching, sorting, algorithm design principles, and concurrency. Each chapter stars with a brief introduction, a case study, top tips, and a review of the most important library methods. This is followed by a broad and thought-provoking set of problems.', '2016-09-15', 'CreateSpace Independent Publishing Platform', 1, '1479274836', '978-1479274833'),
(132, 'A Tour of C++ (C++ In-Depth Series)', ' Bjarne Stroustrup', 'In A Tour of C++, Second Edition, Bjarne Stroustrup, the creator of C++, describes what constitutes modern C++. This concise, self-contained guide covers most major language features and the major standard-library components―not, of course, in great depth, but to a level that gives programmers a meaningful overview of the language, some key examples, and practical help in getting started.\r\n\r\nStroustrup presents the C++ features in the context of the programming styles they support, such as object-oriented and generic programming. His tour is remarkably comprehensive. Coverage begins with the basics, then ranges widely through more advanced topics, including many that are new in C++17, such as move semantics, uniform initialization, lambda expressions, improved containers, random numbers, and concurrency. The tour even covers some extensions being made for C++20, such as concepts and modules, and ends with a discussion of the design and evolution of C++.\r\n\r\nThis guide does not aim to teach you how to program (for that, see Stroustrup’s  Programming: Principles and Practice Using C++, Second Edition), nor will it be the only resource you’ll need for C++ mastery (for that, see Stroustrup’s  The C++ Programming Language, Fourth Edition, and recommended online sources). If, however, you are a C or C++ programmer wanting greater familiarity with the current C++ language, or a programmer versed in another language wishing to gain an accurate picture of the nature and benefits of modern C++, you can’t find a shorter or simpler introduction than this tour provides.', '2018-06-29', 'Pearson Education', 1, '134997832', '978-0134997834'),
(133, 'Cracking the Coding Interview: 189 Programming Questions and Solutions', 'Gayle Laakmann McDowell', ' am not a recruiter. I am a software engineer. And as such, I know what it\'s like to be asked to whip up brilliant algorithms on the spot and then write flawless code on a whiteboard. I\'ve been through this as a candidate and as an interviewer.\r\n\r\nCracking the Coding Interview, 6th Edition is here to help you through this process, teaching you what you need to know and enabling you to perform at your very best. I\'ve coached and interviewed hundreds of software engineers. The result is this book.\r\n\r\nLearn how to uncover the hints and hidden details in a question, discover how to break down a problem into manageable chunks, develop techniques to unstick yourself when stuck, learn (or re-learn) core computer science concepts, and practice on 189 interview questions and solutions.', '2015-07-01', 'CareerCup', 1, '984782869', '978-0984782857'),
(134, 'Elements of Programming Interviews in Java: The Insiders\' Guide', 'Adnan Aziz', 'EPI is your comprehensive guide to interviewing for software development roles.\r\n\r\nThe core of EPI is a collection of over 250 problems with detailed solutions. The problems are representative of interview questions asked at leading software companies. The problems are illustrated with 200 figures, 300 tested programs, and 150 additional variants.\r\n\r\nThe book begins with a summary of the nontechnical aspects of interviewing, such as strategies for a great interview, common mistakes, perspectives from the other side of the table, tips on negotiating the best offer, and a guide to the best ways to use EPI. We also provide a summary of data structures, algorithms, and problem solving patterns.\r\n\r\nCoding problems are presented through a series of chapters on basic and advanced data structures, searching, sorting, algorithm design principles, and concurrency. Each chapter stars with a brief introduction, a case study, top tips, and a review of the most important library methods. This is followed by a broad and thought-provoking set of problems.', '2015-10-06', 'CreateSpace Independent Publishing Platform', 1, '1517671272', '978-1517671273'),
(137, 'Grokking Algorithms: An Illustrated Guide for Programmers and Other Curious People 1st Edition', 'Aditya Bhargava', 'This book is designed to be easy to follow. I avoid big leaps of thought. Any time a new concept is introduced, I explain it right away or tell you when I’ll explain it. Core concepts are reinforced with exercises and multiple explanations so that you can check your assumptions and make sure you’re following along.\r\n\r\nI lead with examples. Instead of writing symbol soup, my goal is to make it easy for you to visualize these concepts. I also think we learn best by being able to recall something we already know, and examples make recall easier. So when you’re trying to remember the difference between arrays and linked lists (explained in chapter 2), you can just think about getting seated for a movie. Also, at the risk of stating the obvious, I’m a visual learner. This book is chock-full of images.\r\n\r\nThe contents of the book are carefully curated. There’s no need to write a book that covers every sorting algorithm—that’s why we have Wikipedia and Khan Academy. All the algorithms I’ve included are practical. I’ve found them useful in my job as a software engineer, and they provide a good foundation for more complex topics. Happy reading!\r\n\r\nThis book is aimed at anyone who knows the basics of coding and wants to understand algorithms. Maybe you already have a coding problem and are trying to find an algorithmic solution. Or maybe you want to understand what algorithms are useful for.', '2016-05-01', 'Manning Publications', 1, '1617292230', '978-1617292231'),
(138, 'Grokking Deep Learning 1st Edition', 'Andrew Trask', 'Artificial Intelligence is one of the most exciting technologies of the century, and Deep Learning is in many ways the \'brain\' behind some of the world\'s smartest Artificial Intelligence systems out there. Loosely based on neuron behavior inside of human brains, these systems are rapidly catching up with the intelligence of their human creators, defeating the world champion Go player, achieving superhuman performance on video games, driving cars, translating languages, and sometimes even helping law enforcement fight crime. Deep Learning is a revolution that is changing every industry across the globe.', '2019-01-25', 'Manning Publications', 1, '1617293709', '978-1617293702'),
(139, 'Building Microservices: Designing Fine-Grained Systems', 'Sam Newman', 'Distributed systems have become more fine-grained in the past 10 years, shifting from code-heavy monolithic applications to smaller, self-contained microservices. But developing these systems brings its own set of headaches. With lots of examples and practical advice, this book takes a holistic view of the topics that system architects and administrators must consider when building, managing, and evolving microservice architectures.\r\n\r\nMicroservice technologies are moving quickly. Author Sam Newman provides you with a firm grounding in the concepts while diving into current solutions for modeling, integrating, testing, deploying, and monitoring your own autonomous services. You’ll follow a fictional company throughout the book to learn how building a microservice architecture affects a single domain.', '2015-03-23', 'O\'Reilly Media', 1, '1491950358', '978-1491950357'),
(140, 'Designing Data-Intensive Applications: The Big Ideas Behind Reliable, Scalable, and Maintainable Systems', 'Martin Kleppmann', 'If you develop applications that have some kind of server/backend for storing or processing data, and your applications use the internet (e.g., web applications, mobile apps, or internet-connected sensors), then this book is for you.\r\n\r\nThis book is for software engineers, software architects, and technical managers who love to code. It is especially relevant if you need to make decisions about the architecture of the systems you work on—for example, if you need to choose tools for solving a given problem and figure out how best to apply them. But even if you have no choice over your tools, this book will help you better understand their strengths and weaknesses.\r\n\r\nYou should have some experience building web-based applications or network services, and you should be familiar with relational databases and SQL. Any non-relational databases and other data-related tools you know are a bonus, but not required. A general understanding of common network protocols like TCP and HTTP is helpful. Your choice of programming language or framework makes no difference for this book.', '2017-04-18', 'O\'Reilly Media', 1, '1449373321', '978-1449373320'),
(141, 'The C++ Programming Language, 4th Edition', 'Bjarne Stroustrup', 'This book features an enhanced, layflat binding, which allows the book to stay open more easily when placed on a flat surface. This special binding method—noticeable by a small space inside the spine—also increases durability. C++11 has arrived: thoroughly master it, with the definitive new guide from C++ creator Bjarne Stroustrup, C++ Programming Language, Fourth Edition! \r\n\r\nThe brand-new edition of the worlds most trusted and widely read guide to C++, it has been comprehensively updated for the long-awaited C++11 standard. Extensively rewritten to present the C++11 language, standard library, and key design techniques as an integrated whole, Stroustrup thoroughly addresses changes that make C++11 feel like a whole new language, offering definitive guidance for leveraging its improvements in performance, reliability, and clarity. \r\n\r\nC++ programmers around the world recognize Bjarne Stoustrup as the go-to expert for the absolutely authoritative and exceptionally useful information they need to write outstanding C++ programs. Now, as C++11 compilers arrive and development organizations migrate to the new standard, they know exactly where to turn once more: Stoustrup C++ Programming Language, Fourth Edition.', '2013-05-09', 'Pearson Education', 1, '0321563840', '978-0321563842'),
(142, 'The Pragmatic Programmer: Your Journey To Mastery, 20th Anniversary Edition (2nd Edition)', 'David Thomas', 'The Pragmatic Programmer is one of those rare tech books you’ll read, re-read, and read again over the years. Whether you’re new to the field or an experienced practitioner, you’ll come away with fresh insights each and every time.\r\n\r\nDave Thomas and Andy Hunt wrote the first edition of this influential book in 1999 to help their clients create better software and rediscover the joy of coding. These lessons have helped a generation of programmers examine the very essence of software development, independent of any particular language, framework, or methodology, and the Pragmatic philosophy has spawned hundreds of books, screencasts, and audio books, as well as thousands of careers and success stories.\r\n\r\nWritten as a series of self-contained sections and filled with classic and fresh anecdotes, thoughtful examples, and interesting analogies, The Pragmatic Programmer illustrates the best approaches and major pitfalls of many different aspects of software development. Whether you’re a new coder, an experienced programmer, or a manager responsible for software projects, use these lessons daily, and you’ll quickly see improvements in personal productivity, accuracy, and job satisfaction. You’ll learn skills and develop habits and attitudes that form the foundation for long-term success in your career.', '2019-09-13', 'Addison-Wesley Professional', 1, '0135957052', '978-0135957059'),
(144, 'wewefwef', 'weefwef', 'qreqerqr', '2021-05-13', 'wefwef', 1, '1234567899', '123-1234567899');

-- --------------------------------------------------------

--
-- Table structure for table `tblborrowed`
--

CREATE TABLE `tblborrowed` (
  `TicketId` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `AccountName` varchar(50) DEFAULT NULL,
  `AccountO365` varchar(50) DEFAULT NULL,
  `AccountNo` varchar(50) DEFAULT NULL,
  `BookId` int(11) DEFAULT NULL,
  `BookTitle` longtext DEFAULT NULL,
  `BookAuthor` varchar(50) DEFAULT NULL,
  `BookDescription` longtext DEFAULT NULL,
  `BookPublishingCompany` varchar(100) DEFAULT NULL,
  `BookPublishingDate` date DEFAULT NULL,
  `PickupDate` date DEFAULT NULL,
  `ReturnDate` date DEFAULT NULL,
  `Common` int(11) NOT NULL DEFAULT 1,
  `S` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblcart`
--

CREATE TABLE `tblcart` (
  `AccountId` int(11) DEFAULT NULL,
  `AccountName` varchar(50) DEFAULT NULL,
  `AccountO365` varchar(50) DEFAULT NULL,
  `AccountNo` varchar(50) DEFAULT NULL,
  `BookId` int(11) DEFAULT NULL,
  `BookTitle` varchar(100) DEFAULT NULL,
  `BookAuthor` varchar(50) DEFAULT NULL,
  `BookDescription` longtext DEFAULT NULL,
  `BookPublishingCompany` varchar(100) DEFAULT NULL,
  `BookPublishingDate` date DEFAULT NULL,
  `Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbldeleted`
--

CREATE TABLE `tbldeleted` (
  `Id` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `AccountO365` varchar(50) DEFAULT NULL,
  `AccountName` varchar(50) DEFAULT NULL,
  `AccountPassword` varchar(225) DEFAULT NULL,
  `AccountContactNo` varchar(50) DEFAULT NULL,
  `AccountRole` int(1) DEFAULT NULL,
  `BookId` int(11) DEFAULT NULL,
  `BookTitle` longtext DEFAULT NULL,
  `BookAuthor` varchar(50) DEFAULT NULL,
  `BookDescription` longtext DEFAULT NULL,
  `BookPublishingDate` date DEFAULT NULL,
  `BookPublishingCompany` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbldeleted`
--

INSERT INTO `tbldeleted` (`Id`, `AccountId`, `AccountO365`, `AccountName`, `AccountPassword`, `AccountContactNo`, `AccountRole`, `BookId`, `BookTitle`, `BookAuthor`, `BookDescription`, `BookPublishingDate`, `BookPublishingCompany`) VALUES
(14, NULL, NULL, NULL, NULL, NULL, NULL, 82, '1', '2', '4', '2021-05-11', '3'),
(15, NULL, NULL, NULL, NULL, NULL, NULL, 83, '1', '2', '4', '2021-05-07', '3'),
(16, 28, 'wewewr.141234@sjdelmonte.sti.edu.ph', 'Student HEHEHEHEHE', '$2y$10$EM.xxkqA7qPF132IsR85uORvZno0Doo1yrNRMOQGA0t3ZdYQzrBoK', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 30, 'regehergf.199097@sjdelmonte.sti.edu.ph', 'Librarian HEHEHE', '$2y$10$8qrYYMvpi1EwIHvvgNwYc.3QmJ.2X9hnFvQY7Onz1UTICrNis2W8u', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 31, 'wegfwefe.124123@sjdelmonte.sti.edu.ph', 'wrgntene', '$2y$10$ITjfPp5wMHstlJC0qgw/p.537vZ/qU6oueg5ZxgiiV59Gl8OcHZZi', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 32, 'eberwgerg.123@sjdelmonte.sti.edu.ph', 'dhergwr wewefwef wefwefwe', '$2y$10$aKftabMwfsFgKSj5izNYYu1N5QphJ5gz.xcOVk2rANjZOhUuCGBH2', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(20, NULL, NULL, NULL, NULL, NULL, NULL, 84, '1', '2', '4', '2021-05-12', '3'),
(21, NULL, NULL, NULL, NULL, NULL, NULL, 85, '1', '2', '4', '2021-05-17', '3'),
(22, 33, 'qwdqwdqwqf.1212@sjdelmonte.sti.edu.ph', 'srgweg wefwef wefw ef', '$2y$10$6.U7bFxemdkaTxSKs/CTCOE2whCR1MIiBG15Z9V0aX7xbclvih55u', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 34, 'wegwefwewbwe.123@sjdelmonte.sti.edu.ph', 'wsgwefw wef wef wefwef', '$2y$10$L8b/PDa6chJmpFzf6RQ4T.FxWvgridnrEm4OSLRYTIy48ar8xmzNG', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 35, 'wrbwrberber.1231532@sjdelmonte.sti.edu.ph', 'awqf qwwedqwd qwd qw', '$2y$10$FsrKmHXxSM.IGfSpKcELe.bQdR255AlfSToL0lJ9QHtUJDH7WYctu', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 36, 'wefwef.123123@sjdelmonte.sti.edu.ph', 'weefew wef wefe w', '$2y$10$6SqZU2DogACFLsgyQ/DQLuJBDg6Asdp4ccYyKeGvgRU84Tsn4vaiG', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 37, 'wewewe.99999999999999997@sjdelmonte.sti.edu.ph', 'eq qw qw', '$2y$10$X.hPbxaDdHXMDoMjj4.8Ker7QdkDYzjPHhPko5h7XigCZRK/ehSWu', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 38, 'aqqweqwewwddwd.122@sjdelmonte.sti.edu.ph', 'weef werrw wer', '$2y$10$K.XyC495nKD/9bQrE9DhHuatMBaZEizieMAbT05CW8yFOYUPdT98O', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 39, 'ace.123@sjdelmonte.sti.edu.ph', 'qwr qwe ', '$2y$10$zKYnS5FREkOYsxf4kSzUrO5MraTmVQHk2IKmo.GgAMaTnJQetGYZ2', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 40, 'qqq.q11@sjdelmonte.sti.edu.ph', 'wefwe we ', '$2y$10$wU0Bo4R.xGYvzGkF/eccfOUttXLXlbLCM8SN.G3p4VLGIu7LDKlX6', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 41, 'qqwd.qwwddq111@sjdelmonte.sti.edu.ph', 'wg weefwef', '$2y$10$wwYMalfLQsxpKTa7oDDAPeAYurJV8Moa53xTzFTrK33LtJqakZ0kC', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 42, 'sindao.123456@sjdelmonte.sti.edu.ph', 'Louis Matthew Sindao', '$2y$10$5k82TlfQiDOKUYwDcoWZ/.bPJCydfY0256zRzDGYnzrPmVwC8CZ7u', '09123456789', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 11, 'admin.123456@sjdelmonte.sti.edu.ph', 'Admin Acccount', '$2y$10$t8OjgQROirPuOcKKbvCChepDnx/Qg9aUMa4DOXSBttJ7YMbebljoW', '09437440050', 1, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 11, 'admin.123456@sjdelmonte.sti.edu.ph', 'Admin Acccount', '$2y$10$t8OjgQROirPuOcKKbvCChepDnx/Qg9aUMa4DOXSBttJ7YMbebljoW', '09437440050', 1, NULL, NULL, NULL, NULL, NULL, NULL),
(34, 29, 'wefwef.234123@sjdelmonte.sti.edu.ph', 'Librarian HEHEHEHEHE', '$2y$10$fpFEJIJEAv8.0afNum/eS.41.cTlsNWqYonQzaAOEAgaFlLkXAWJG', '09437440050', 2, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 20, 'librarian.199097@sjdelmonte.sti.edu.ph', 'Librarian Ako', '$2y$10$HnYYjzGmcHzDj/UiCvmwdua4z2LNMyfjMXJ89Mh1ucNcOx0oiNpAC', '09123456789', 2, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 49, 'qqwdqwd.123123@sjdelmonte.sti.edu.ph', 'qwdqw qwdqwd', '$2y$10$73ly6MIJvo7nJeZgEkXHvu6EIaI.EY263WdMWBgvjcfFmAwE53sJu', '09101112131', 2, NULL, NULL, NULL, NULL, NULL, NULL),
(37, 47, 'yabot.199097@sjdelmonte.sti.edu.ph', 'Dan Leo L. Yabot Jr.', '$2y$10$88J0q0c4gNUFE4e0wPSc6OcSLhlPaEZv3p0hSAoKYVzdo4gtmiYca', '09437440050', 2, NULL, NULL, NULL, NULL, NULL, NULL),
(38, 51, 'qwqwdqwd.123123@sjdelmonte.sti.edu.ph', 'qqwqwe qweqweqw', '$2y$10$ab/OBb9jV52lw7iaGyRLIeFsxxRbDNgZ31.GEgQbOUszVgkJ81zta', '09437440050', 2, NULL, NULL, NULL, NULL, NULL, NULL),
(39, 50, 'wefwefw.123123@sjdelmonte.sti.edu.ph', 'wefwfe wef wefwef', '$2y$10$0j97.LYwY8lqKNUFASatuOXufgmwcPNuj./31yWKEoSTQixdoOGLq', '09876543219', 2, NULL, NULL, NULL, NULL, NULL, NULL),
(40, 53, 'qwdqwdwqd.19123@sjdelmonte.sti.edu.ph', 'qwqwdq wdqdqwd qwd', '$2y$10$zgDPGSHWVDpstRDJT/1Ji.gh2hLsoTVLIEcfcHddGmz8XKEAZof9.', '09345678910', 2, NULL, NULL, NULL, NULL, NULL, NULL),
(41, 54, 'qefqwqwqwd.123123@sjdelmonte.sti.edu.ph', 'qwqdeqw qwdqw', '$2y$10$2EV007BKg2UmWwWOY6zL9u.Q6wnXmiu5iVNuHodW31n6fT/4QPgkq', '09876543219', 2, NULL, NULL, NULL, NULL, NULL, NULL),
(42, 52, 'student.123456@sjdelmonte.sti.edu.ph', 'Student Account', '$2y$10$ua3gDhFIbUdz50p6N2cnfe50xHtvpaVIbJPFWYwHBMv/ageYNfuai', '09437440050', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(43, 55, 'student.123456@sjdelmonte.sti.edu.ph', 'Student Account', '$2y$10$Re.cLqpZPlHoBGTFuTVEV.URxvnjDbC2bhMv4m4tt4PK42ioCOD.K', '09876543211', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(44, NULL, NULL, NULL, NULL, NULL, NULL, 135, 'How to counter your inner demons', 'Jake Louie Birad', 'Pano makaiwas sa demonyo sa discord lalo na pag last name mayorga', '2021-05-12', 'Beerad Publishing Company'),
(45, NULL, NULL, NULL, NULL, NULL, NULL, 136, 'Guide to become a Java Man', 'Java Jake', 'become a java man', '2021-05-10', 'Jake Inc'),
(46, NULL, NULL, NULL, NULL, NULL, NULL, 143, 'qweqwe', 'qweqweq', 'rwerfwefwfwef', '2021-05-19', 'weqwe');

-- --------------------------------------------------------

--
-- Table structure for table `tblreserveticket`
--

CREATE TABLE `tblreserveticket` (
  `TicketId` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `AccountName` varchar(50) DEFAULT NULL,
  `AccountO365` varchar(50) DEFAULT NULL,
  `AccountNo` varchar(50) DEFAULT NULL,
  `BookId` int(11) DEFAULT NULL,
  `BookTitle` longtext DEFAULT NULL,
  `BookAuthor` varchar(50) DEFAULT NULL,
  `BookDescription` longtext DEFAULT NULL,
  `BookPublishingCompany` varchar(100) DEFAULT NULL,
  `BookPublishingDate` date DEFAULT NULL,
  `Common` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblreserveticket`
--

INSERT INTO `tblreserveticket` (`TicketId`, `AccountId`, `AccountName`, `AccountO365`, `AccountNo`, `BookId`, `BookTitle`, `BookAuthor`, `BookDescription`, `BookPublishingCompany`, `BookPublishingDate`, `Common`) VALUES
(677, 11, 'Admin Acccount', 'admin.123456@sjdelmonte.sti.edu.ph', '09437440050', 132, 'A Tour of C++ (C++ In-Depth Series)', ' Bjarne Stroustrup', 'In A Tour of C++, Second Edition, Bjarne Stroustrup, the creator of C++, describes what constitutes modern C++. This concise, self-contained guide covers most major language features and the major standard-library components―not, of course, in great depth, but to a level that gives programmers a meaningful overview of the language, some key examples, and practical help in getting started.\r\n\r\nStroustrup presents the C++ features in the context of the programming styles they support, such as object-oriented and generic programming. His tour is remarkably comprehensive. Coverage begins with the basics, then ranges widely through more advanced topics, including many that are new in C++17, such as move semantics, uniform initialization, lambda expressions, improved containers, random numbers, and concurrency. The tour even covers some extensions being made for C++20, such as concepts and modules, and ends with a discussion of the design and evolution of C++.\r\n\r\nThis guide does not aim to teach you how to program (for that, see Stroustrup’s  Programming: Principles and Practice Using C++, Second Edition), nor will it be the only resource you’ll need for C++ mastery (for that, see Stroustrup’s  The C++ Programming Language, Fourth Edition, and recommended online sources). If, however, you are a C or C++ programmer wanting greater familiarity with the current C++ language, or a programmer versed in another language wishing to gain an accurate picture of the nature and benefits of modern C++, you can’t find a shorter or simpler introduction than this tour provides.', 'Pearson Education', '2018-06-29', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblaccounts`
--
ALTER TABLE `tblaccounts`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblbooks`
--
ALTER TABLE `tblbooks`
  ADD PRIMARY KEY (`BookId`);

--
-- Indexes for table `tblborrowed`
--
ALTER TABLE `tblborrowed`
  ADD PRIMARY KEY (`TicketId`);

--
-- Indexes for table `tblcart`
--
ALTER TABLE `tblcart`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbldeleted`
--
ALTER TABLE `tbldeleted`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblreserveticket`
--
ALTER TABLE `tblreserveticket`
  ADD PRIMARY KEY (`TicketId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblaccounts`
--
ALTER TABLE `tblaccounts`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `tblbooks`
--
ALTER TABLE `tblbooks`
  MODIFY `BookId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `tblborrowed`
--
ALTER TABLE `tblborrowed`
  MODIFY `TicketId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=397;

--
-- AUTO_INCREMENT for table `tblcart`
--
ALTER TABLE `tblcart`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=379;

--
-- AUTO_INCREMENT for table `tbldeleted`
--
ALTER TABLE `tbldeleted`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `tblreserveticket`
--
ALTER TABLE `tblreserveticket`
  MODIFY `TicketId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=678;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
